"use client";
// The message box (text + mic) and the message list, shared by Home and Chat.
import { useEffect, useRef, useState } from "react";
import { useApp } from "@/lib/store";
import { send, startListening, stopListening } from "@/lib/assistant";
import { Icon, ICONS } from "../ui";

export function Composer({ id, quick = true, compact = false }: { id: string; quick?: boolean; compact?: boolean }) {
  const [text, setText] = useState("");
  const orb = useApp((s) => s.orb);
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  const spoken = useApp((s) => s.settings.spokenReplies);
  const listening = orb === "listening";

  const submit = () => { const t = text; setText(""); void send(t); };
  const toggleMic = () => {
    if (listening) stopListening();
    else startListening((partial) => setText(partial));
  };
  const suggestions = ["What should I work on next?", "Plan my day", "Explain recursion simply", "Start a focus session"];

  return (
    <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="stack" style={{ gap: 12, width: "100%", maxWidth: compact ? "none" : 620, margin: compact ? 0 : "0 auto" }}>
      <label htmlFor={id} className="sr-only">Message {name}</label>
      <div className="composer">
        <input id={id} className="field" type="text" autoComplete="off" value={text} onChange={(e) => setText(e.target.value)}
          placeholder={listening ? "Listening…" : `Ask ${name} anything…`}
          style={{ flex: 1, minWidth: 0, height: 44, padding: "0 12px", background: "transparent", border: 0, color: "var(--t1)", font: "inherit", fontSize: 15, outline: "none" }} />
        <button type="button" className="btn btn-icon" onClick={toggleMic} aria-pressed={listening} aria-label={listening ? "Stop listening" : "Start voice input"}
          style={listening ? { background: "var(--a)", color: "#08090A" } : undefined}>
          <Icon d={ICONS.mic} />
        </button>
        <button type="submit" aria-label="Send" className="btn-icon" style={{ background: "var(--a)", color: "#08090A" }}>
          <Icon d={ICONS.send} stroke={2} />
        </button>
      </div>
      {quick && (
        <div className="row" style={{ flexWrap: "wrap", gap: 8, justifyContent: compact ? "flex-start" : "center" }}>
          {suggestions.map((s) => (
            <button key={s} type="button" className="btn" onClick={() => void send(s)}
              style={{ minHeight: 34, padding: "0 13px", background: "transparent", border: "1px solid rgba(var(--ink),.09)", borderRadius: 999, color: "var(--t2)", font: "inherit", fontSize: 13, cursor: "pointer" }}>{s}</button>
          ))}
          <button type="button" className="btn" aria-pressed={spoken} onClick={() => useApp.getState().updateSettings({ spokenReplies: !spoken })}
            style={{ minHeight: 34, padding: "0 13px", background: spoken ? "var(--a-soft)" : "transparent", border: `1px solid ${spoken ? "transparent" : "rgba(var(--ink),.09)"}`, borderRadius: 999, color: spoken ? "var(--a-ink)" : "var(--t2)", font: "inherit", fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
            <Icon d={ICONS.speaker} size={14} stroke={2} />{spoken ? "Voice on" : "Voice off"}
          </button>
        </div>
      )}
    </form>
  );
}

export function Messages({ limit, emptyText }: { limit?: number; emptyText?: string }) {
  const messages = useApp((s) => s.messages);
  const orb = useApp((s) => s.orb);
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  const end = useRef<HTMLDivElement>(null);
  const shown = limit ? messages.slice(-limit) : messages;
  useEffect(() => { if (!limit) end.current?.scrollIntoView({ block: "end" }); }, [messages, limit]);

  if (!shown.length && orb !== "thinking") return <span className="sub" style={{ padding: "16px 0" }}>{emptyText ?? `No messages yet. Say hello to ${name}.`}</span>;
  return (
    <div aria-live="polite" className="stack" style={{ gap: 12 }}>
      {shown.map((m) => (
        <div key={m.id} className="stack" style={{ gap: 4, alignItems: m.role === "user" ? "flex-end" : "flex-start" }}>
          <span style={{ fontSize: 11, color: "var(--t3)" }}>{m.role === "user" ? "You" : name}</span>
          <p className={`bubble ${m.role === "user" ? "me" : "ai"}`}>{m.text || "…"}</p>
        </div>
      ))}
      {orb === "thinking" && (
        <div className="stack" style={{ gap: 4, alignItems: "flex-start" }}>
          <span style={{ fontSize: 11, color: "var(--t3)" }}>{name}</span>
          <div aria-label={`${name} is thinking`} className="row bubble ai" style={{ gap: 5, padding: "12px 14px" }}><span className="tdot" /><span className="tdot" /><span className="tdot" /></div>
        </div>
      )}
      <div ref={end} />
    </div>
  );
}

const STATUS = { idle: "Standing by", listening: "Listening", thinking: "Working on it", speaking: "Responding" };

export function StatusLine() {
  const orb = useApp((s) => s.orb);
  return (
    <div aria-live="polite" className="row" style={{ justifyContent: "center", gap: 10, fontSize: 15, fontWeight: 500 }}>
      <span className={`eq ${orb === "idle" ? "still" : ""}`} aria-hidden="true"><span /><span /><span /><span /></span>
      {STATUS[orb]}
    </div>
  );
}
