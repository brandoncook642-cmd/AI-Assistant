// GLSL shaders for the particle core (ported unchanged from the design).
// The vertex shader places every particle: it builds each of the 15 shapes,
// morphs between two of them, then applies the state effects (listening
// scatter, thinking twist and orbit ring, speaking waves), the startup
// fly-in, the mode-change shock and the cursor push.

export const PARTICLE_VS = `attribute vec4 aSeed;
uniform float uT,uScatter,uRing,uWave,uPulse,uLevel,uSpin,uDpr,uSize,uShapeA,uShapeB,uMorph,uDensity,uTwist,uIntro,uShock,uHover,uAspect,uScale,uSizeMul;uniform vec2 uMouse;
varying float vA;varying float vR;
float gF;
mat2 rot(float a){return mat2(cos(a),-sin(a),sin(a),cos(a));}
vec3 shape(float id,vec3 d,float r){
 float az=atan(d.z,d.x);
 if(id<.5)return d*.55;
 if(id<1.5){float ph=asin(clamp(d.y,-1.,1.))*2.+r*.3;float R=.42+.15*cos(ph);return vec3(R*cos(az),.15*sin(ph),R*sin(az));}
 if(id<2.5){float f=fract(r*13.37);float rad=.06+.62*pow(f,.8);float arm=step(.5,fract(r*97.13))*3.14159;
  float ang=rad*6.5+arm+d.x*.45/(rad*3.+.4);vec3 g=vec3(cos(ang)*rad,d.y*.05*(1.-rad),sin(ang)*rad);
  return mix(g,d*.13,step(fract(r*7.77),.14));}
 if(id<3.5){float k=floor(fract(r*17.3)*3.);float a=az+uT*(1.2+k*.35);
  vec3 o=vec3(cos(a)*.62,0.,sin(a)*.2)+d*.01;o.xy=rot(k*1.0472)*o.xy;
  return mix(o,d*.1,step(fract(r*5.91),.18));}
 if(id<4.5){float rad=.5+.22*fract(r*19.7);vec3 ring=vec3(cos(az)*rad,d.y*.008,sin(az)*rad);ring.xy=rot(.3)*ring.xy;
  return mix(ring,d*.34,step(fract(r*3.71),.55));}
 if(id<5.5){float k=floor(fract(r*17.3)*3.);vec3 c=vec3(cos(az)*.55,sin(az)*.55,0.);
  c=k<.5?c:(k<1.5?c.xzy:c.zxy);return c+d*.012;}
 if(id<6.5){float ri=floor(fract(r*23.1)*6.);float rad=.1+ri*.1;
  vec3 q=vec3(cos(az)*rad,sin(rad*18.-uT*3.)*.035,sin(az)*rad)+d*.005;q.yz=rot(.55)*q.yz;
  return mix(q,d*.03,step(fract(r*9.1),.05));}
 if(id<7.5){float h=fract(r*13.37);float rad=.06+.52*h*h;float a=az+h*9.-uT*1.6;
  return vec3(cos(a)*rad,(h-.55)*.95,sin(a)*rad)+d*.008;}
 if(id<8.5)return d*mix(.58,.27,step(fract(r*5.3),.35));
 if(id<9.5){float k=floor(fract(r*17.3)*5.);vec3 c=vec3(cos(az)*.58,0.,sin(az)*.58)+d*.008;
  c.yz=rot(k*.63)*c.yz;c.xz=rot(k*1.26+uT*(.18+k*.07)*(mod(k,2.)*2.-1.))*c.xz;
  return mix(c,d*.16,step(fract(r*5.91),.2));}
 if(id<10.5){float k=floor(fract(r*17.3)*3.);float R=.62-k*.14;vec3 c;
  if(k<.5){c=vec3(cos(az),sin(az),0.)*R;c.xz=rot(uT*.5)*c.xz;}
  else if(k<1.5){c=vec3(cos(az),0.,sin(az))*R;c.yz=rot(uT*.8)*c.yz;}
  else{c=vec3(0.,cos(az),sin(az))*R;c.xy=rot(uT*1.2)*c.xy;}
  return mix(c+d*.008,d*.07,step(fract(r*5.91),.08));}
 if(id<11.5){float sel=fract(r*3.17);float lat=asin(clamp(d.y,-1.,1.));
  float lon=floor(fract(r*13.1)*8.)*.3927;vec3 mer=vec3(cos(lat)*cos(lon),sin(lat),cos(lat)*sin(lon))*.58;
  float lp=(floor(fract(r*7.3)*5.)-2.)*.5;vec3 par=vec3(cos(lp)*cos(az),sin(lp),cos(lp)*sin(az))*.58;
  return sel<.15?d*.2:(sel<.4?par:mer);}
 if(id<12.5){float sel=fract(r*5.3);vec3 p;
  if(sel<.45){p=d*.6;p.xz=rot(uT*.3)*p.xz;}
  else if(sel<.78){p=d*.42;p.xy=rot(-uT*.5)*p.xy;}
  else{p=d*.24;p.yz=rot(uT*.8)*p.yz;}
  return p;}
 if(id<13.5){if(fract(r*3.91)<.3)return d*.2;
  float lat=asin(clamp(d.y,-1.,1.));float b=floor((lat+1.5708)/.4488);
  float lq=-1.5708+(b+.5)*.4488+(fract(r*29.3)-.5)*.1;float a=az+uT*.4*(mod(b,2.)*2.-1.);
  return vec3(cos(lq)*cos(a),sin(lq),cos(lq)*sin(a))*.6;}
 if(fract(r*3.37)<.35)return d*.22;
 float f=fract(r*7.13+uT*.22);gF=1.-f;return d*(.24+f*.5);
}
void main(){
 vec3 d=aSeed.xyz;float r=aSeed.w;
 gF=1.;vec3 sa=shape(uShapeA,d,r);float fa=gF;gF=1.;vec3 sb=shape(uShapeB,d,r);float fb=gF;
 vec3 b=mix(sa,sb,uMorph);float fade=mix(fa,fb,uMorph);
 b*=1.+.025*sin(uT*1.3+r*6.283);
 b+=.018*vec3(sin(uT*.7+r*40.),sin(uT*.9+r*31.),cos(uT*.8+r*23.));
 vec3 n=normalize(b+vec3(.0001));
 float lat=asin(clamp(n.y,-1.,1.));
 float band=sin(lat*9.-uT*7.)*sin(atan(n.z,n.x)*3.+uT*2.);
 vec3 p=b+n*uWave*(band*.08*uPulse+uPulse*.05);
 p.xz=rot(p.y*uTwist*3.*sin(uT*1.5))*p.xz;
 float th=atan(d.z,d.x)+uT*(1.4+r);
 vec3 o=vec3(cos(th)*.74,sin(uT*2.+r*20.)*.015,sin(th)*.74);o.xy=rot(.5)*o.xy;
 p=mix(p,o,uRing*step(.78,r));
 p*=1.+uScatter*(.12+.75*uLevel*r*r);
 p+=n*uScatter*.06*sin(uT*7.+r*60.);
 p*=1.+uShock*(.18+.3*r)*sin(uShock*3.14159);
 float ie=clamp(uIntro*1.5-r*.5,0.,1.);ie=1.-pow(1.-ie,3.);
 vec3 fr=normalize(d+vec3(.0001))*(2.4+r*2.6);fr.xz=rot(r*9.+uT*.2)*fr.xz;
 p=mix(fr,p,ie);
 p.xz=rot(uT*uSpin)*p.xz;
 p.yz=rot(.38)*p.yz;
 float persp=1.7/(2.5-p.z);
 float vis=step(fract(r*7.31),uDensity);
 vec2 sp=p.xy*persp*1.12*uScale;sp.x/=uAspect;
 vec2 dv=sp-uMouse;float dd=length(dv);
 sp+=dv/(dd+.001)*uHover*.1*exp(-dd*dd*14.)+uMouse*uHover*.03;
 gl_Position=vec4(sp,0.,1.);
 gl_PointSize=vis*uSize*uSizeMul*uDpr*persp*(.55+r*.9)*(1.+uPulse*.35)*(.4+.6*ie);
 vA=(.25+.75*clamp((p.z+.7)/1.4,0.,1.))*fade;vR=r;
}`;

export const PARTICLE_FS = `precision mediump float;uniform vec3 uA;uniform vec3 uC;uniform float uSpec;uniform float uAlphaMul;varying float vA;varying float vR;
vec3 hue(float h){return clamp(abs(mod(h*6.+vec3(0.,4.,2.),6.)-3.)-1.,0.,1.);}
void main(){vec2 c=gl_PointCoord-.5;float a=1.-smoothstep(0.,.5,length(c));a*=a;
vec3 col=mix(uA,uC,smoothstep(.45,1.,vR)*.9);col=mix(col,mix(hue(vR),vec3(1.),.15),uSpec);col=mix(col,vec3(1.),smoothstep(.965,1.,vR)*.7);
float k=a*vA*uAlphaMul;gl_FragColor=vec4(col*k,k);}`;

export const FADE_VS = `attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}`;
export const FADE_FS = `precision mediump float;uniform float uK;void main(){gl_FragColor=vec4(0.,0.,0.,uK);}`;
