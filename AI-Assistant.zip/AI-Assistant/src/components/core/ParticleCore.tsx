"use client";
// The assistant's particle core, with its instrument frame and readouts.
import { useEffect, useRef, useState } from "react";
import { startEngine } from "./engine";

const TICKS = Array.from({ length: 72 }, (_, i) => {
  const a = (i * 5 * Math.PI) / 180;
  const major = i % 6 === 0;
  const r2 = major ? 184 : 190;
  return { x1: 200 + 196 * Math.sin(a), y1: 200 - 196 * Math.cos(a), x2: 200 + r2 * Math.sin(a), y2: 200 - r2 * Math.cos(a), major };
});

function arc(a0: number, a1: number, r: number) {
  const p = (a: number) => [200 + r * Math.sin((a * Math.PI) / 180), 200 - r * Math.cos((a * Math.PI) / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 0 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`;
}
const BRACKETS = [45, 135, 225, 315].map((a) => arc(a - 12, a + 12, 204)).join(" ");
const LABELS = [[0, "000"], [90, "090"], [180, "180"], [270, "270"]] as const;

export interface CoreProps {
  coreColour: string;
  glow: number;
  glowScale: number;
  rings: boolean;
  hud?: boolean;
  readouts?: { tl: string; tr: string; bl: string; br: string };
  bootLabel?: string | null;
  maxWidth?: number;
}

export default function ParticleCore({ coreColour, glow, glowScale, rings, hud, readouts, bootLabel, maxWidth }: CoreProps) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const stop = startEngine(ref.current, "main");
    if (!stop) setFailed(true);
    return () => stop?.();
  }, []);

  return (
    <div className="core-box" style={maxWidth ? { maxWidth } : undefined}>
      <div aria-hidden="true" style={{
        position: "absolute", inset: "8%", borderRadius: "50%",
        background: `radial-gradient(circle, color-mix(in srgb, ${coreColour} 32%, transparent) 0%, transparent 62%)`,
        opacity: glow, transform: `scale(${glowScale})`, transition: "opacity .6s, transform .6s", filter: "blur(12px)",
      }} />
      {rings && (<><div aria-hidden="true" className="halo-ring" style={{ borderColor: coreColour }} /><div aria-hidden="true" className="halo-ring r2" style={{ borderColor: coreColour }} /></>)}
      {hud && (
        <svg className="hud-frame" viewBox="0 0 400 400" aria-hidden="true">
          <g className="hud-rot" stroke="var(--t1)">
            {TICKS.map((t, i) => (
              <line key={i} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} strokeWidth={t.major ? 1.2 : 0.8} strokeOpacity={t.major ? 0.55 : 0.28} />
            ))}
          </g>
          <circle cx="200" cy="200" r="178" fill="none" stroke="rgba(var(--ink),.14)" strokeDasharray="2 6" />
          <circle cx="200" cy="200" r="150" fill="none" stroke="rgba(var(--ink),.06)" />
          <path d={BRACKETS} fill="none" stroke={coreColour} strokeWidth="2" strokeLinecap="round" strokeOpacity=".8" />
          <g className="hud-labels" fill="var(--t3)">
            {LABELS.map(([a, l]) => (
              <text key={l} x={200 + 166 * Math.sin((a * Math.PI) / 180)} y={200 - 166 * Math.cos((a * Math.PI) / 180) + 3} textAnchor="middle">{l}</text>
            ))}
          </g>
        </svg>
      )}
      {hud && readouts && (
        <>
          <span className="hud-read tl hide-sm">MODE<b>{readouts.tl}</b></span>
          <span className="hud-read tr hide-sm">LOCAL<b className="num">{readouts.tr}</b></span>
          <span className="hud-read bl hide-sm">CORE<b>{readouts.bl}</b></span>
          <span className="hud-read br hide-sm">STATE<b>{readouts.br}</b></span>
        </>
      )}
      {bootLabel && (
        <div className="boot-label" aria-live="polite">
          <span style={{ fontSize: 13, fontWeight: 600, letterSpacing: ".32em", color: "var(--t1)" }}>{bootLabel.toUpperCase()}</span>
          <span className="boot-sub">Initialising</span>
        </div>
      )}
      <canvas ref={ref} aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", display: "block" }} />
      {failed && <div className="core-fallback" aria-hidden="true" />}
    </div>
  );
}

export function BackgroundCore() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const stop = startEngine(ref.current, "background");
    return () => stop?.();
  }, []);
  return <canvas ref={ref} aria-hidden="true" className="bg-core" />;
}
