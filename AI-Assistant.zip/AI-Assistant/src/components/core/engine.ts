// WebGL renderer for the particle core. One engine per canvas.
// "main" is the interactive core; "background" is the faint giant swarm.
import { core, tickCore } from "./coreState";
import { FADE_FS, FADE_VS, PARTICLE_FS, PARTICLE_VS } from "./shaders";

const UNIFORMS = [
  "uT", "uScatter", "uRing", "uWave", "uPulse", "uLevel", "uSpin", "uDpr", "uSize", "uA", "uC",
  "uShapeA", "uShapeB", "uMorph", "uDensity", "uTwist", "uSpec", "uIntro", "uShock", "uHover",
  "uAspect", "uScale", "uSizeMul", "uMouse", "uAlphaMul",
] as const;

function compile(gl: WebGLRenderingContext, vs: string, fs: string): WebGLProgram | null {
  const make = (type: number, src: string) => {
    const sh = gl.createShader(type)!;
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.warn(gl.getShaderInfoLog(sh));
      return null;
    }
    return sh;
  };
  const v = make(gl.VERTEX_SHADER, vs);
  const f = make(gl.FRAGMENT_SHADER, fs);
  if (!v || !f) return null;
  const p = gl.createProgram()!;
  gl.attachShader(p, v);
  gl.attachShader(p, f);
  gl.linkProgram(p);
  return gl.getProgramParameter(p, gl.LINK_STATUS) ? p : null;
}

/** Evenly spread points on a sphere (Fibonacci lattice) plus a random value each. */
function makeSeeds(n: number): Float32Array {
  const seeds = new Float32Array(n * 4);
  const ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < n; i++) {
    const y = 1 - (i / (n - 1)) * 2;
    const r = Math.sqrt(1 - y * y);
    const th = ga * i;
    const j = 0.04;
    const x = Math.cos(th) * r + (Math.random() - 0.5) * j;
    const yy = y + (Math.random() - 0.5) * j;
    const z = Math.sin(th) * r + (Math.random() - 0.5) * j;
    const l = Math.hypot(x, yy, z) || 1;
    seeds.set([x / l, yy / l, z / l, Math.random()], i * 4);
  }
  return seeds;
}

export function startEngine(canvas: HTMLCanvasElement, kind: "main" | "background"): (() => void) | null {
  const isMain = kind === "main";
  const gl = canvas.getContext("webgl", { premultipliedAlpha: true, alpha: true, antialias: true, preserveDrawingBuffer: isMain });
  if (!gl) return null;
  const prog = compile(gl, PARTICLE_VS, PARTICLE_FS);
  if (!prog) return null;
  const fade = compile(gl, FADE_VS, FADE_FS);

  const count = isMain ? (canvas.clientWidth < 340 ? 4200 : 7000) : 2600;
  const seedBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, seedBuf);
  gl.bufferData(gl.ARRAY_BUFFER, makeSeeds(count), gl.STATIC_DRAW);
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

  const U = Object.fromEntries(UNIFORMS.map((n) => [n, gl.getUniformLocation(prog, n)])) as Record<(typeof UNIFORMS)[number], WebGLUniformLocation | null>;
  const seedLoc = gl.getAttribLocation(prog, "aSeed");
  const fadeK = fade ? gl.getUniformLocation(fade, "uK") : null;
  const fadeLoc = fade ? gl.getAttribLocation(fade, "p") : -1;
  gl.enable(gl.BLEND);

  if (isMain) core.mainActive = true;
  let raf = 0;
  const frame = (now: number) => {
    raf = requestAnimationFrame(frame);
    const dpr = Math.min(window.devicePixelRatio || 1, isMain ? 2 : 1.25);
    const w = Math.round(canvas.clientWidth * dpr);
    const h = Math.round(canvas.clientHeight * dpr);
    if (!w || !h) return;
    let resized = false;
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; resized = true; }
    gl.viewport(0, 0, w, h);
    const t = (now - core.t0) / 1000;
    if (isMain || !core.mainActive) tickCore(t);

    const intro = isMain ? Math.min(1, Math.max(0, (now - core.introStart) / 2200)) : 1;
    const shockV = Math.max(0, 1 - (now - core.shockStart) / 900);
    const k = core.sw;

    if (isMain && core.fx.trails && fade && !resized) {
      const busy = core.orb === "thinking" || core.morph.m < 0.97 || intro < 1 || shockV > 0;
      gl.useProgram(fade);
      gl.blendFunc(gl.ZERO, gl.ONE_MINUS_SRC_ALPHA);
      gl.bindBuffer(gl.ARRAY_BUFFER, quad);
      gl.enableVertexAttribArray(fadeLoc);
      gl.vertexAttribPointer(fadeLoc, 2, gl.FLOAT, false, 0, 0);
      gl.uniform1f(fadeK, busy ? 0.16 : 0.42);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    } else {
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }

    gl.useProgram(prog);
    gl.blendFunc(gl.ONE, core.light ? gl.ONE_MINUS_SRC_ALPHA : gl.ONE);
    gl.bindBuffer(gl.ARRAY_BUFFER, seedBuf);
    gl.enableVertexAttribArray(seedLoc);
    gl.vertexAttribPointer(seedLoc, 4, gl.FLOAT, false, 0, 0);
    const dk = core.light ? 0.78 : 1;
    const [r, g, b] = core.colour, [r2, g2, b2] = core.colour2;
    gl.uniform1f(U.uT, t);
    gl.uniform1f(U.uScatter, k.scatter);
    gl.uniform1f(U.uRing, k.ring);
    gl.uniform1f(U.uWave, k.wave);
    gl.uniform1f(U.uPulse, k.pulse);
    gl.uniform1f(U.uLevel, k.level);
    gl.uniform1f(U.uTwist, k.twist);
    gl.uniform1f(U.uShapeA, core.morph.a);
    gl.uniform1f(U.uShapeB, core.morph.b);
    gl.uniform1f(U.uMorph, core.morph.m);
    gl.uniform1f(U.uDensity, isMain ? core.density : 1);
    gl.uniform1f(U.uSpin, k.spin * core.spinMul * (isMain ? 1 : 0.5));
    gl.uniform1f(U.uDpr, dpr);
    gl.uniform1f(U.uSize, (isMain ? Math.max(1.6, canvas.clientWidth / 210) : 2.2) * core.size);
    gl.uniform3f(U.uA, r * dk, g * dk, b * dk);
    gl.uniform3f(U.uC, r2 * dk, g2 * dk, b2 * dk);
    gl.uniform1f(U.uSpec, core.spectrum);
    gl.uniform1f(U.uIntro, intro);
    gl.uniform1f(U.uShock, shockV);
    gl.uniform1f(U.uAspect, Math.max(1, w / h));
    gl.uniform1f(U.uScale, isMain ? 1 : Math.min(1.5, (h / w) * 2.2 + 0.6));
    gl.uniform2f(U.uMouse, isMain ? core.mouse.sx : 0, isMain ? core.mouse.sy : 0);
    gl.uniform1f(U.uHover, isMain ? core.mouse.hover : 0);
    if (isMain && core.fx.bloom) {
      gl.uniform1f(U.uSizeMul, 4.2);
      gl.uniform1f(U.uAlphaMul, 0.07);
      gl.drawArrays(gl.POINTS, 0, count);
    }
    gl.uniform1f(U.uSizeMul, 1);
    gl.uniform1f(U.uAlphaMul, isMain ? 1 : 0.55);
    gl.drawArrays(gl.POINTS, 0, count);
  };
  raf = requestAnimationFrame(frame);

  return () => {
    cancelAnimationFrame(raf);
    if (isMain) core.mainActive = false;
    gl.getExtension("WEBGL_lose_context")?.loseContext();
  };
}
