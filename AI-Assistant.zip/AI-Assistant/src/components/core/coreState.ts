// Live values the WebGL core reads every frame. Kept outside React so that
// animation never causes re-renders. The app writes into it; the engine reads.
import type { OrbState } from "@/lib/types";
import { shapeIndex } from "@/lib/theme";

type Num3 = [number, number, number];

export const core = {
  orb: "idle" as OrbState,
  colour: [0.31, 0.72, 1] as Num3,
  colour2: [0.43, 0.94, 0.82] as Num3,
  spectrum: 0,
  light: false,
  density: 1,
  size: 1,
  spinMul: 1,
  fx: { bloom: true, trails: true, cursor: true },
  morph: { a: 9, b: 9, m: 1 },
  sw: { scatter: 0, ring: 0, wave: 0, twist: 0, pulse: 0, spin: 0.12, level: 0 },
  mouse: { x: 0, y: 0, sx: 0, sy: 0, hover: 0, inside: false },
  level: 0, // live microphone level 0..1
  kick: 0, // bumped on each spoken/streamed word
  talking: false, // true while words are actually streaming or being spoken
  introStart: typeof performance !== "undefined" ? performance.now() : 0,
  shockStart: -1e9,
  mainActive: false,
  t0: typeof performance !== "undefined" ? performance.now() : 0,
};

export function setCoreShape(name: string) {
  const i = shapeIndex(name);
  const m = core.morph;
  if (m.b === i) return;
  core.morph = { a: m.m > 0.5 ? m.b : m.a, b: i, m: 0 };
}

export function snapCoreShape(name: string) {
  const i = shapeIndex(name);
  core.morph = { a: i, b: i, m: 1 };
}

export function replayIntro() {
  core.introStart = performance.now();
}

export function shock() {
  core.shockStart = performance.now();
}

/** Eases the swarm parameters towards the targets for the current state. */
export function tickCore(t: number) {
  const st = core.orb;
  core.kick *= 0.88;
  let lvl = core.level;
  if (st === "listening" && lvl < 0.02) lvl = 0.25 + 0.25 * Math.abs(Math.sin(t * 3.1) * Math.sin(t * 1.7 + 1));
  const syll = Math.max(core.kick, core.talking ? 0 : 0.5 + 0.5 * Math.sin(t * 11) * Math.sin(t * 3.3));
  const targets = {
    idle: { scatter: 0, ring: 0, wave: 0, twist: 0, pulse: 0.06 + 0.05 * Math.sin(t * 1.4), spin: 0.12, level: 0 },
    listening: { scatter: 1, ring: 0, wave: 0, twist: 0, pulse: lvl * 0.6, spin: 0.18, level: lvl },
    thinking: { scatter: 0, ring: 1, wave: 0, twist: 1, pulse: 0.12, spin: 0.6, level: 0 },
    speaking: { scatter: 0.08, ring: 0, wave: 1, twist: 0, pulse: syll, spin: 0.2, level: 0 },
  }[st];
  const fast = st === "speaking" || st === "listening" ? 0.22 : 0.06;
  const sw = core.sw as Record<string, number>;
  for (const k of Object.keys(targets) as (keyof typeof targets)[]) {
    const e = k === "ring" || k === "wave" || k === "scatter" || k === "twist" ? 0.045 : fast;
    sw[k] += (targets[k] - sw[k]) * e;
  }
  core.morph.m += (1 - core.morph.m) * 0.045;
  const mo = core.mouse;
  mo.sx += (mo.x - mo.sx) * 0.12;
  mo.sy += (mo.y - mo.sy) * 0.12;
  mo.hover += ((core.fx.cursor && mo.inside ? 1 : 0) - mo.hover) * 0.08;
}
