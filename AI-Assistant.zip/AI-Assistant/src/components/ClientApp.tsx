"use client";
// The assistant is fully interactive and uses browser-only APIs (WebGL,
// speech, localStorage), so it renders on the client only.
import dynamic from "next/dynamic";

const AssistantApp = dynamic(() => import("./AssistantApp"), {
  ssr: false,
  loading: () => <div style={{ minHeight: "100vh", background: "#08090A" }} />,
});

export default function ClientApp() {
  return <AssistantApp />;
}
