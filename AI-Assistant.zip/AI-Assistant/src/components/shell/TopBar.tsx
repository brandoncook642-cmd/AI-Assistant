"use client";
import { useState } from "react";
import { useApp } from "@/lib/store";
import { changeMode } from "@/lib/assistant";
import type { Mode } from "@/lib/types";
import { MODE_LABEL } from "@/lib/theme";
import { Icon, ICONS } from "../ui";

function timeAgo(at: number) {
  const s = Math.max(0, Math.round((Date.now() - at) / 1000));
  return s < 60 ? "Just now" : s < 3600 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`;
}

function NotificationBell() {
  const [open, setOpen] = useState(false);
  const notifications = useApp((s) => s.notifications);
  const unread = notifications.filter((n) => !n.read).length;
  const app = useApp.getState;
  return (
    <div style={{ position: "relative" }}>
      <button type="button" className="btn" onClick={() => setOpen(!open)} aria-label={`Notifications, ${unread} unread`} aria-expanded={open}
        style={{ position: "relative", width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 8, border: "1px solid rgba(var(--ink),.08)", background: "rgba(var(--ink),.035)", color: "var(--t2)", cursor: "pointer" }}>
        <Icon d={ICONS.bell} />
        {unread > 0 && <span className="num badge">{unread}</span>}
      </button>
      {open && (
        <div className="notif-pop" role="dialog" aria-label="Notifications">
          <div className="row" style={{ justifyContent: "space-between", padding: "12px 14px", borderBottom: "1px solid rgba(var(--ink),.07)" }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>Notifications</span>
            <span className="row" style={{ gap: 4 }}>
              <button type="button" className="btn btn-link" onClick={() => app().markAllRead()}>Mark all read</button>
              <button type="button" className="btn btn-link" onClick={() => app().clearNotifications()}>Clear</button>
            </span>
          </div>
          {notifications.length === 0 ? (
            <div className="stack" style={{ padding: "32px 16px", textAlign: "center", gap: 4 }}>
              <span style={{ fontSize: 14 }}>You’re all caught up</span>
              <span className="sub">Event reminders and task nudges appear here.</span>
            </div>
          ) : (
            <ul style={{ margin: 0, padding: 6, listStyle: "none", maxHeight: 360, overflowY: "auto" }}>
              {notifications.map((n) => (
                <li key={n.id}>
                  <button type="button" className="btn list-btn" style={{ alignItems: "flex-start", background: n.read ? "transparent" : "rgba(var(--ink),.035)" }}
                    onClick={() => { app().readNotification(n.id); setOpen(false); if (n.page) useApp.setState({ page: n.page }); }}>
                    <span style={{ width: 30, height: 30, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 8, background: "var(--a-soft)", color: "var(--a-ink)" }}>
                      <Icon d={n.kind === "task" ? ICONS.tasks : n.kind === "event" ? ICONS.calendar : ICONS.bell} size={15} />
                    </span>
                    <span className="stack" style={{ flex: 1, minWidth: 0, gap: 2 }}>
                      <span style={{ fontSize: 13.5, fontWeight: 500 }}>{n.title}</span>
                      <span style={{ fontSize: 12.5, color: "var(--t2)", lineHeight: 1.4 }}>{n.body}</span>
                      <span className="sub" style={{ fontSize: 11.5 }}>{timeAgo(n.at)}</span>
                    </span>
                    {!n.read && <span style={{ width: 8, height: 8, marginTop: 6, borderRadius: "50%", background: "var(--a)" }} />}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

export default function TopBar({ title, sub }: { title: string; sub: string }) {
  const mode = useApp((s) => s.mode);
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  return (
    <header className="topbar">
      <div className="stack" style={{ gap: 2, marginRight: "auto", minWidth: 0 }}>
        <h1 style={{ margin: 0 }}>{title}</h1>
        <span className="sub" style={{ fontSize: 13 }}>{sub}</span>
      </div>
      <button type="button" className="btn search" onClick={() => useApp.setState({ paletteOpen: true })}
        style={{ flex: "0 1 300px", minHeight: 40, display: "flex", alignItems: "center", gap: 10, padding: "0 12px", background: "rgba(var(--ink),.035)", border: "1px solid rgba(var(--ink),.08)", borderRadius: 8, color: "var(--t3)", fontSize: 13, cursor: "pointer", textAlign: "left" }}>
        <Icon d={ICONS.search} size={16} />
        <span style={{ flex: 1 }}>Search or ask {name}…</span>
        <span className="kbd">⌘K</span>
      </button>
      <div role="group" aria-label="Operating mode" className="seg">
        {(["standard", "focus", "alert"] as Mode[]).map((m) => (
          <button key={m} type="button" className="seg-btn btn" aria-pressed={mode === m}
            onClick={(e) => changeMode(m, { x: e.clientX, y: e.clientY })} style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: mode === m ? "var(--core)" : "rgba(var(--ink),.2)" }} />
            {MODE_LABEL[m]}
          </button>
        ))}
      </div>
      <NotificationBell />
    </header>
  );
}
