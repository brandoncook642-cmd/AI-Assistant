"use client";
import { useApp } from "@/lib/store";
import type { Page } from "@/lib/types";
import { Icon, ICONS } from "../ui";

const NAV: { page: Page; label: string; icon: string }[] = [
  { page: "home", label: "Home", icon: ICONS.home },
  { page: "chat", label: "Chat", icon: ICONS.chat },
  { page: "tasks", label: "Tasks", icon: ICONS.tasks },
  { page: "schedule", label: "Schedule", icon: ICONS.calendar },
  { page: "code", label: "Code", icon: ICONS.code },
  { page: "settings", label: "Settings", icon: ICONS.settings },
];

export function LogoMark({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="var(--a-ink)" strokeWidth="1.4" aria-hidden="true">
      <circle cx="12" cy="12" r="9.5" />
      <ellipse cx="12" cy="12" rx="9.5" ry="3.6" />
      <ellipse cx="12" cy="12" rx="3.6" ry="9.5" />
      <circle cx="12" cy="12" r="2.2" fill="var(--a-ink)" stroke="none" />
    </svg>
  );
}

export default function Rail() {
  const page = useApp((s) => s.page);
  const name = useApp((s) => s.settings.userName);
  const go = (p: Page) => useApp.setState({ page: p });
  return (
    <nav className="rail" aria-label="Main">
      <div className="rail-logo" style={{ width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 18, borderRadius: 8, background: "var(--a-soft)", boxShadow: "inset 0 0 0 1px color-mix(in srgb, var(--a) 30%, transparent)" }}>
        <LogoMark />
      </div>
      {NAV.map((n) => {
        const on = page === n.page;
        return (
          <button key={n.page} type="button" className="nav-btn" onClick={() => go(n.page)} aria-label={n.label} title={n.label}
            aria-current={on ? "page" : undefined} style={{ background: on ? "var(--a-soft)" : "transparent", color: on ? "var(--a-ink)" : "var(--t3)" }}>
            <Icon d={n.icon} size={20} stroke={1.7} />
          </button>
        );
      })}
      <div className="rail-spacer" />
      <div className="rail-logo" aria-label={name ? `Signed in as ${name}` : "You"}
        style={{ width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "50%", background: "linear-gradient(135deg, var(--a), var(--a2))", color: "#08090A", fontSize: 13, fontWeight: 600 }}>
        {(name || "You").charAt(0).toUpperCase()}
      </div>
    </nav>
  );
}
