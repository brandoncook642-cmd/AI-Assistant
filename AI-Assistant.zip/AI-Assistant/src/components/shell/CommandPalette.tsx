"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "@/lib/store";
import { changeMode, send, startListening } from "@/lib/assistant";
import { ACCENTS, MODE_LABEL, SHAPES } from "@/lib/theme";
import { setCoreShape } from "../core/coreState";
import type { Mode, Page, ThemeChoice } from "@/lib/types";
import { Icon, ICONS } from "../ui";

interface Cmd { label: string; group: string; icon: string; run: () => void }

export default function CommandPalette() {
  const open = useApp((s) => s.paletteOpen);
  return open ? <Palette /> : null;
}

function Palette() {
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => { input.current?.focus(); }, []);

  const close = () => useApp.setState({ paletteOpen: false });

  const cmds = useMemo<Cmd[]>(() => {
    const app = useApp.getState();
    const say = (t: string) => app.flash(t);
    const go = (p: Page) => () => useApp.setState({ page: p });
    const base: Cmd[] = [
      ...(["home", "chat", "tasks", "schedule", "code", "settings"] as Page[]).map((p) => ({ label: `Go to ${p[0].toUpperCase() + p.slice(1)}`, group: "Navigate", icon: ICONS.arrow, run: go(p) })),
      { label: "Start listening", group: "Voice", icon: ICONS.mic, run: () => startListening(() => {}) },
      { label: "Start a focus session", group: "Focus", icon: ICONS.clock, run: () => { app.startFocus(); say("Focus session started"); } },
      { label: "Clear completed tasks", group: "Tasks", icon: ICONS.tasks, run: () => { app.clearDone(); say("Completed tasks cleared"); } },
      ...(["standard", "focus", "alert"] as Mode[]).map((m) => ({ label: `Switch to ${MODE_LABEL[m]} mode`, group: "Mode", icon: ICONS.bolt, run: () => changeMode(m) })),
      ...(["dark", "light", "system"] as ThemeChoice[]).map((t) => ({ label: `Theme: ${t[0].toUpperCase() + t.slice(1)}`, group: "Theme", icon: ICONS.palette, run: () => app.updateSettings({ theme: t }) })),
      ...SHAPES.map((s) => ({ label: `Core shape: ${s.name}`, group: "Core", icon: s.icon, run: () => { app.updateSettings({ shape: s.name }); setCoreShape(s.name); say(`Core set to ${s.name}`); } })),
      ...ACCENTS.map((a) => ({ label: `Accent colour: ${a.label}`, group: "Theme", icon: ICONS.palette, run: () => app.updateSettings({ accent: a.id }) })),
    ];
    const query = q.trim();
    if (!query) return base.slice(0, 9);
    const words = query.toLowerCase().split(/\s+/);
    const matches = base.filter((c) => words.every((w) => `${c.label} ${c.group}`.toLowerCase().includes(w)));
    const addMatch = /^add task\s+(.+)/i.exec(query);
    const extra: Cmd[] = [
      { label: `Add task: ${addMatch ? addMatch[1] : query}`, group: "Tasks", icon: ICONS.plus, run: () => { app.addTask(addMatch ? addMatch[1] : query); say("Task added"); } },
      { label: `Ask ${name}: ${query}`, group: "Chat", icon: ICONS.chat, run: () => { useApp.setState({ page: "chat" }); void send(query); } },
    ];
    return (addMatch ? [...extra, ...matches] : [...matches, ...extra]).slice(0, 9);
  }, [q, name]);

  const run = (c: Cmd) => { close(); c.run(); };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 50, display: "flex", justifyContent: "center", alignItems: "flex-start", padding: "12vh 16px 16px" }}>
      <button type="button" aria-label="Close command palette" onClick={close} style={{ position: "absolute", inset: 0, border: 0, background: "rgba(4,5,6,.62)", backdropFilter: "blur(6px)", cursor: "default" }} />
      <div role="dialog" aria-modal="true" aria-label="Command palette" className="palette-pop"
        style={{ position: "relative", width: "100%", maxWidth: 580, borderRadius: 12, background: "var(--pop)", border: "1px solid rgba(var(--ink),.1)", boxShadow: "0 40px 80px -20px rgba(0,0,0,.8)", overflow: "hidden" }}>
        <div className="row" style={{ gap: 10, padding: "0 16px", borderBottom: "1px solid rgba(var(--ink),.07)", color: "var(--t3)" }}>
          <Icon d={ICONS.search} />
          <label htmlFor="palette-q" className="sr-only">Command</label>
          <input id="palette-q" ref={input} autoComplete="off" value={q} placeholder={`Type a command or ask ${name}…`}
            onChange={(e) => { setQ(e.target.value); setSel(0); }}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, cmds.length - 1)); }
              else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
              else if (e.key === "Enter") { e.preventDefault(); if (cmds[sel]) run(cmds[sel]); }
              else if (e.key === "Escape") { e.preventDefault(); close(); }
            }}
            style={{ flex: 1, minWidth: 0, height: 54, background: "transparent", border: 0, color: "var(--t1)", font: "inherit", fontSize: 16, outline: "none" }} />
          <span className="kbd">esc</span>
        </div>
        <ul role="listbox" aria-label="Commands" style={{ margin: 0, padding: 6, listStyle: "none", maxHeight: 380, overflowY: "auto" }}>
          {cmds.map((c, i) => (
            <li key={c.label} role="option" aria-selected={i === sel}>
              <button type="button" onClick={() => run(c)} onMouseEnter={() => setSel(i)}
                style={{ width: "100%", minHeight: 44, display: "flex", alignItems: "center", gap: 12, padding: "0 12px", border: 0, borderRadius: 8, background: i === sel ? "rgba(var(--ink),.07)" : "transparent", color: "var(--t1)", font: "inherit", fontSize: 14, textAlign: "left", cursor: "pointer" }}>
                <span style={{ width: 24, height: 24, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 6, background: "rgba(var(--ink),.05)", color: i === sel ? "var(--a-ink)" : "var(--t2)" }}><Icon d={c.icon} size={14} /></span>
                <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.label}</span>
                <span style={{ fontSize: 11.5, color: "var(--t3)" }}>{c.group}</span>
              </button>
            </li>
          ))}
        </ul>
        <div className="row" style={{ gap: 16, padding: "10px 16px", borderTop: "1px solid rgba(var(--ink),.07)", fontSize: 12, color: "var(--t3)" }}>
          <span><span className="kbd">↑</span> <span className="kbd">↓</span> to move</span><span><span className="kbd">↵</span> to run</span>
        </div>
      </div>
    </div>
  );
}
