"use client";
// Root of the app: theme, startup sequence, page switching and overlays.
import { useCallback, useEffect, useMemo, useState, useSyncExternalStore, type CSSProperties, type MouseEvent } from "react";
import { useApp } from "@/lib/store";
import { useFx } from "@/lib/fx";
import { resolveColours, hexToRgb, rgba } from "@/lib/theme";
import { playSound } from "@/lib/sound";
import { dateKey, DAY_LONG, fmtTime, greeting, minutesNow, mondayOf, todayIndex } from "@/lib/time";
import { core, replayIntro, setCoreShape, snapCoreShape } from "./core/coreState";
import { BackgroundCore } from "./core/ParticleCore";
import Rail from "./shell/Rail";
import TopBar from "./shell/TopBar";
import CommandPalette from "./shell/CommandPalette";
import HomeView from "./views/HomeView";
import { ChatView, CodeView, ScheduleView, TasksView } from "./views/OtherViews";
import SettingsView from "./views/SettingsView";
import Onboarding from "./views/Onboarding";

const BOOT_MS = 1900;

const LIGHT_QUERY = "(prefers-color-scheme: light)";
function useSystemLight() {
  return useSyncExternalStore(
    (cb) => { const mq = window.matchMedia(LIGHT_QUERY); mq.addEventListener("change", cb); return () => mq.removeEventListener("change", cb); },
    () => window.matchMedia(LIGHT_QUERY).matches,
    () => false,
  );
}

function Toast() {
  const toast = useApp((s) => s.toast);
  useEffect(() => {
    if (!toast) return;
    playSound("tick");
    const id = setTimeout(() => useApp.setState({ toast: null }), 2800);
    return () => clearTimeout(id);
  }, [toast]);
  if (!toast) return null;
  return (
    <div role="status" className="toast" key={toast.id} style={{ position: "fixed", left: "50%", bottom: 24, zIndex: 60, transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: 10, padding: "10px 16px", borderRadius: 10, background: "var(--toast)", border: "1px solid rgba(var(--ink),.1)", boxShadow: "0 20px 40px -10px rgba(0,0,0,.7)", fontSize: 13.5, maxWidth: "calc(100vw - 32px)" }}>
      <span style={{ width: 18, height: 18, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "50%", background: "var(--a)", color: "#08090A" }}>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10" /></svg>
      </span>
      {toast.text}
    </div>
  );
}

function FxLayer() {
  const { bursts, ripples } = useFx();
  return (
    <>
      {ripples.map((r) => <div key={r.id} aria-hidden="true" className="ripple" style={{ left: r.x, top: r.y, borderColor: r.colour, boxShadow: `0 0 60px ${r.colour}, inset 0 0 60px ${r.colour}` }} />)}
      {bursts.map((b) => (
        <div key={b.id} aria-hidden="true" style={{ position: "fixed", left: b.x, top: b.y, width: 0, height: 0, zIndex: 70, pointerEvents: "none" }}>
          {Array.from({ length: 14 }, (_, i) => {
            const ang = (i / 14) * Math.PI * 2, dist = 34 + (i % 3) * 14, size = 4 + (i % 3) * 2;
            const c = i % 2 ? "var(--a)" : "var(--a2)";
            return <span key={i} className="bdot" style={{ width: size, height: size, background: c, boxShadow: `0 0 8px ${c}`, ["--dx" as string]: `${(Math.cos(ang) * dist).toFixed(1)}px`, ["--dy" as string]: `${(Math.sin(ang) * dist).toFixed(1)}px` } as CSSProperties} />;
          })}
        </div>
      ))}
    </>
  );
}

/** Event reminders and task nudges. */
function useReminders(booting: boolean) {
  useEffect(() => {
    if (booting) return;
    const fire = (n: Parameters<ReturnType<typeof useApp.getState>["notify"]>[0], silent = false) => {
      const app = useApp.getState();
      if (!app.notify(n)) return;
      if (!silent) { playSound("bell"); app.flash(`${n.title} — ${n.body}`); }
      try { if (typeof Notification !== "undefined" && Notification.permission === "granted" && document.hidden) new Notification(n.title, { body: n.body }); } catch { /* ignore */ }
    };
    const check = (atStart: boolean) => {
      const { settings, events, tasks, onboarded } = useApp.getState();
      if (!onboarded) return;
      const ti = todayIndex(), mins = minutesNow(), key = dateKey();
      const today = events.filter((e) => e.day === ti).sort((a, b) => a.start - b.start);
      if (settings.remindEvents) {
        for (const e of today) {
          const until = e.start - mins;
          if (until > 0 && until <= settings.leadMinutes) fire({ key: `ev-${e.id}-${key}`, kind: "event", title: `Starts in ${until} min`, body: e.title, page: "schedule" });
        }
        if (atStart) {
          const next = today.find((e) => e.start > mins + settings.leadMinutes);
          if (next) fire({ key: `next-${next.id}-${key}`, kind: "event", title: `Coming up at ${fmtTime(next.start)}`, body: next.title, page: "schedule" }, true);
        }
      }
      if (settings.nudgeTasks && atStart) {
        const due = tasks.filter((t) => !t.done && t.due === "Today");
        if (due.length) fire({ key: `tasks-${key}`, kind: "task", title: `${due.length} task${due.length > 1 ? "s" : ""} due today`, body: due.slice(0, 2).map((t) => t.label).join(", ") + (due.length > 2 ? "…" : ""), page: "tasks" });
      }
    };
    const first = setTimeout(() => check(true), 2200);
    const id = setInterval(() => check(false), 30000);
    return () => { clearTimeout(first); clearInterval(id); };
  }, [booting]);
}

export default function AssistantApp() {
  const s = useApp();
  const hydrated = s.hydrated;
  const systemLight = useSystemLight();
  const [booting, setBooting] = useState(true);
  const [now, setNow] = useState(() => new Date());

  // Startup sequence.
  useEffect(() => {
    if (!hydrated) return;
    snapCoreShape(useApp.getState().settings.shape);
    replayIntro();
    const id = setTimeout(() => setBooting(false), BOOT_MS);
    return () => clearTimeout(id);
  }, [hydrated]);
  const replay = useCallback(() => {
    playSound("boot");
    useApp.setState({ page: "home" });
    replayIntro();
    setBooting(true);
    setTimeout(() => setBooting(false), BOOT_MS);
  }, []);

  useEffect(() => { const id = setInterval(() => setNow(new Date()), 15000); return () => clearInterval(id); }, []);

  // ⌘K / Ctrl+K opens the command palette.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); useApp.setState({ paletteOpen: true }); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useReminders(booting || !s.onboarded);

  const light = s.settings.theme === "light" || (s.settings.theme === "system" && systemLight);
  const colours = useMemo(() => resolveColours(s.settings.accent, s.settings.customAccent, s.mode, s.settings.coreFollowsMode), [s.settings.accent, s.settings.customAccent, s.mode, s.settings.coreFollowsMode]);

  // Push settings into the WebGL core.
  useEffect(() => {
    const st = s.settings;
    core.colour = hexToRgb(colours.core).map((v) => v / 255) as [number, number, number];
    core.colour2 = hexToRgb(st.palette === "mono" ? colours.core : colours.core2).map((v) => v / 255) as [number, number, number];
    core.spectrum = st.palette === "spectrum" ? 1 : 0;
    core.light = light;
    core.density = st.density;
    core.size = st.particleSize;
    core.spinMul = st.spin;
    core.fx = { bloom: st.effects.bloom, trails: st.effects.trails, cursor: st.effects.cursor };
    core.orb = s.orb;
    setCoreShape(st.shape);
  }, [s.settings, s.orb, colours, light]);

  // Cursor position for the core, plus the card spotlight and tilt.
  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    const canvas = document.querySelector(".core-box canvas") as HTMLCanvasElement | null;
    if (canvas) {
      const r = canvas.getBoundingClientRect();
      const nx = ((e.clientX - r.left) / r.width) * 2 - 1, ny = -(((e.clientY - r.top) / r.height) * 2 - 1);
      core.mouse.x = nx; core.mouse.y = ny; core.mouse.inside = Math.hypot(nx, ny) < 1.6;
    }
    const el = (e.target as HTMLElement).closest?.(".card") as HTMLElement | null;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top, big = r.width > 600 ? 0.4 : 1;
    el.style.setProperty("--mx", `${x}px`);
    el.style.setProperty("--my", `${y}px`);
    el.style.setProperty("--rx", `${(-(y / r.height - 0.5) * 5 * big).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${((x / r.width - 0.5) * 5 * big).toFixed(2)}deg`);
    el.style.setProperty("--sx", `${((x / r.width) * 100).toFixed(1)}%`);
  };

  if (!hydrated) return <div style={{ minHeight: "100vh", background: "#08090A" }} />;

  const name = s.settings.assistantName.trim() || "Assistant";
  const orb = s.orb;
  const coreProps = {
    coreColour: colours.core,
    glow: { idle: 0.55, listening: 0.9, thinking: 0.75, speaking: 1 }[orb],
    glowScale: { idle: 1, listening: 1.12, thinking: 0.92, speaking: 1.08 }[orb],
    rings: orb === "listening" || orb === "speaking",
  };
  const ti = todayIndex(now);
  const active = s.tasks.filter((t) => !t.done).length;
  const titles: Record<string, [string, string]> = {
    home: [s.settings.userName ? `${greeting(now)}, ${s.settings.userName}` : greeting(now), `${DAY_LONG[ti]}, ${now.toLocaleDateString(undefined, { day: "numeric", month: "long" })} · ${now.toTimeString().slice(0, 5)}`],
    chat: ["Chat", `Talk to ${name} by text or voice`],
    tasks: ["Tasks", `${active} active · ${s.tasks.length - active} done`],
    schedule: ["Schedule", `Week of ${mondayOf(now).toLocaleDateString(undefined, { day: "numeric", month: "long" })}`],
    code: ["Code", `Paste code and ${name} will explain it`],
    settings: ["Settings", "Assistant, AI connection, voice and appearance"],
  };
  const fx = s.settings.effects;

  const wrapStyle = {
    position: "relative", minHeight: "100vh", isolation: "isolate",
    background: `color-mix(in srgb, var(--core) 7%, var(--bg))`,
    color: "var(--t1)", WebkitFontSmoothing: "antialiased",
    "--a": colours.accent, "--a2": colours.accent2, "--a-soft": rgba(colours.accent, 0.13), "--core": colours.core,
  } as CSSProperties;

  return (
    <div className={`wrap ${booting ? "booting" : ""} ${fx.tilt ? "fx-tilt" : ""} ${light ? "light" : ""} ${!s.onboarded ? "onboarding" : ""}`} style={wrapStyle}
      onMouseMove={onMove} onMouseLeave={() => { core.mouse.inside = false; }}>
      {fx.mesh && (
        <div aria-hidden="true" style={{ position: "fixed", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
          <div className="mesh m1" style={{ background: `radial-gradient(circle, ${rgba(colours.accent, 0.22)} 0%, transparent 62%)` }} />
          <div className="mesh m2" style={{ background: `radial-gradient(circle, ${rgba(colours.accent2, 0.18)} 0%, transparent 62%)` }} />
          <div className="mesh m3" style={{ background: "radial-gradient(circle, rgba(60,90,255,.12) 0%, transparent 62%)" }} />
        </div>
      )}
      {fx.bgCore && s.onboarded && <BackgroundCore />}

      {!s.onboarded ? (
        <Onboarding booting={booting} coreProps={coreProps} onDone={() => useApp.setState({ page: "home" })} />
      ) : (
        <div className="app">
          <Rail />
          <main className="main">
            <TopBar title={titles[s.page][0]} sub={titles[s.page][1]} />
            {s.page === "home" && <HomeView booting={booting} coreProps={coreProps} />}
            {s.page === "chat" && <ChatView coreProps={coreProps} />}
            {s.page === "tasks" && <TasksView />}
            {s.page === "schedule" && <ScheduleView />}
            {s.page === "code" && <CodeView />}
            {s.page === "settings" && <SettingsView onReplay={replay} />}
          </main>
        </div>
      )}
      <CommandPalette />
      <FxLayer />
      <Toast />
    </div>
  );
}
