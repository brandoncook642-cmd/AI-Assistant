"use client";
import { useEffect, useMemo, useState } from "react";
import { useApp, weekHours, streakDays } from "@/lib/store";
import { writeBrief } from "@/lib/briefing";
import { speak } from "@/lib/speech";
import { send } from "@/lib/assistant";
import { playSound } from "@/lib/sound";
import { burstAt } from "@/lib/fx";
import { dateKey, fmtTime, minutesNow, todayIndex, DAY_SHORT } from "@/lib/time";
import { MODE_LABEL } from "@/lib/theme";
import { core } from "../core/coreState";
import ParticleCore from "../core/ParticleCore";
import { Composer, Messages, StatusLine } from "../assistant/Conversation";
import { CardTitle, EmptyState, Icon, ICONS } from "../ui";
import type { Task } from "@/lib/types";

const KIND_COLOUR = { class: "var(--a)", study: "var(--a2)", project: "#FFB020", check: "#8E9497" };

export function useCountUp(deps: unknown[]) {
  const [p, setP] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const step = () => { const v = Math.min(1, (performance.now() - start) / 1100); setP(v); if (v < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return 1 - Math.pow(1 - p, 3);
}

export function TaskRow({ t }: { t: Task }) {
  return (
    <button type="button" className="btn list-btn" aria-pressed={t.done} style={{ margin: "0 -10px", width: "calc(100% + 20px)" }}
      onClick={(e) => {
        const nowDone = useApp.getState().toggleTask(t.id);
        if (nowDone) { playSound("done"); burstAt(e.clientX, e.clientY); useApp.getState().flash("Task completed"); }
      }}>
      <span className={`check ${t.done ? "on pop" : ""}`}>{t.done && <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#08090A" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={ICONS.check} /></svg>}</span>
      <span className="stack" style={{ flex: 1, minWidth: 0, gap: 2 }}>
        <span style={{ fontSize: 13.5, color: t.done ? "var(--t3)" : "var(--t1)", textDecoration: t.done ? "line-through" : "none" }}>{t.label}</span>
        <span className="sub">{t.done ? "Completed" : t.due === "Today" ? "Due today" : `Due ${t.due.toLowerCase()}`}</span>
      </span>
      {t.priority && !t.done && <span className="chip" style={{ fontSize: 11 }}>Priority</span>}
    </button>
  );
}

/** The daily brief, typed out word by word. */
function BriefCard({ title, text, chips }: { title: string; text: string; chips: string[] }) {
  const [n, setN] = useState(0);
  const words = text.split(" ");
  useEffect(() => {
    const id = setInterval(() => setN((x) => (x >= words.length ? x : x + 1)), 38);
    return () => clearInterval(id);
  }, [words.length]);
  const readAloud = () => {
    useApp.setState({ orb: "speaking" }); core.orb = "speaking"; core.talking = true;
    speak(text, () => { core.kick = 1; }, () => { core.talking = false; useApp.setState({ orb: "idle" }); core.orb = "idle"; });
  };
  return (
    <section className="card brief a-brief" aria-label={title} style={{ display: "flex", gap: 20, alignItems: "flex-start", padding: "18px 20px" }}>
      <span className="brief-ic" aria-hidden="true"><Icon d={ICONS.sun} size={20} stroke={1.7} /></span>
      <div className="stack" style={{ flex: 1, minWidth: 0, gap: 10 }}>
        <CardTitle>{title}</CardTitle>
        <p aria-live="polite" style={{ margin: 0, fontSize: 15, lineHeight: 1.6, color: "var(--t1b)" }}>
          {words.slice(0, n).join(" ")}{n < words.length && <span className="caret-b" aria-hidden="true" />}
        </p>
        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
          {chips.map((c) => <span key={c} style={{ padding: "5px 10px", borderRadius: 999, background: "rgba(var(--ink),.05)", fontSize: 12.5, color: "var(--t2)" }}>{c}</span>)}
          <span style={{ flex: 1 }} />
          <button type="button" className="btn btn-ghost" onClick={readAloud}><Icon d={ICONS.speaker} size={14} stroke={2} />Read aloud</button>
          <button type="button" className="btn-primary" style={{ minHeight: 34, fontSize: 13 }} onClick={() => { useApp.setState({ page: "chat" }); void send("Plan my day"); }}>Plan my day</button>
        </div>
      </div>
      <button type="button" className="btn btn-icon" style={{ width: 32, height: 32 }} aria-label="Hide brief for today" onClick={() => useApp.setState({ briefHiddenOn: dateKey() })}><Icon d={ICONS.close} size={16} stroke={2} /></button>
    </section>
  );
}

function sortTasks(tasks: Task[]) {
  const rank = { Today: 0, Tomorrow: 1, "This week": 2 };
  return [...tasks].sort((a, b) => Number(a.done) - Number(b.done) || Number(b.priority) - Number(a.priority) || rank[a.due] - rank[b.due]);
}

export default function HomeView({ booting, coreProps }: { booting: boolean; coreProps: { coreColour: string; glow: number; glowScale: number; rings: boolean } }) {
  const s = useApp();
  const name = s.settings.assistantName || "Assistant";
  const hours = useMemo(() => weekHours(s.sessions), [s.sessions]);
  const streak = streakDays(s.sessions);
  const ti = todayIndex();
  const mins = minutesNow();
  const today = s.events.filter((e) => e.day === ti).sort((a, b) => a.start - b.start);
  const ez = useCountUp([booting]);
  const [clock, setClock] = useState(() => Date.now());
  useEffect(() => { if (!s.focusStart) return; const id = setInterval(() => setClock(Date.now()), 1000); return () => clearInterval(id); }, [s.focusStart]);

  const brief = useMemo(() => writeBrief(name, s.tasks, s.events, hours), [name, s.tasks, s.events, hours]);
  const showBrief = s.briefHiddenOn !== dateKey();

  const start = [
    { label: "Add your first task", done: s.tasks.length > 0, run: () => useApp.setState({ page: "tasks" }) },
    { label: `Say hello to ${name}`, done: s.messages.some((m) => m.role === "user"), run: () => document.getElementById("home-cmd")?.focus() },
    { label: "Add an event to your week", done: s.events.length > 0, run: () => useApp.setState({ page: "schedule" }) },
    { label: "Try a focus session", done: s.sessions.length > 0 || !!s.focusStart, run: () => s.startFocus() },
    { label: "Make the core yours", done: s.customised, run: () => useApp.setState({ page: "settings" }) },
  ];
  const startDone = start.filter((x) => x.done).length;
  const tasks = sortTasks(s.tasks).slice(0, 4);
  const doneCount = s.tasks.filter((t) => t.done).length;
  const hasFocus = hours.some((x) => x > 0);
  const wmax = Math.max(...hours, 0.01);
  const elapsed = s.focusStart ? Math.max(0, Math.floor((clock - s.focusStart) / 1000)) : 0;

  return (
    <div className="board page-in">
      <div aria-hidden="true" className="core-light" style={{ background: `radial-gradient(closest-side, color-mix(in srgb, ${coreProps.coreColour} 20%, transparent), transparent)`, opacity: coreProps.glow }} />

      <div className="col col-left">
        <section className="a-today card rise d2" aria-label="Today" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card-head"><CardTitle idx="01">Today</CardTitle><button type="button" className="btn btn-link" onClick={() => useApp.setState({ page: "schedule" })}>+ Add event</button></div>
          {today.length ? (
            <ol style={{ margin: 0, padding: 0, listStyle: "none" }}>
              {today.map((e) => {
                const past = mins >= e.start + e.duration, now = mins >= e.start && !past;
                return (
                  <li key={e.id} style={{ display: "grid", gridTemplateColumns: "48px 12px minmax(0,1fr)", gap: 10, padding: "9px 0" }}>
                    <span className="num" style={{ fontSize: 12.5, color: now ? "var(--a-ink)" : "var(--t3)" }}>{fmtTime(e.start)}</span>
                    <span style={{ width: 9, height: 9, marginTop: 4, borderRadius: "50%", border: `2px solid ${past ? "rgba(var(--ink),.18)" : KIND_COLOUR[e.kind]}`, background: now ? KIND_COLOUR[e.kind] : "transparent" }} />
                    <span className="stack" style={{ gap: 2, minWidth: 0 }}>
                      <span style={{ fontSize: 13.5, color: past ? "var(--t3)" : "var(--t1)" }}>{e.title}</span>
                      <span className="sub">{now ? "Now · " : ""}{e.duration >= 60 ? `${e.duration / 60}h` : `${e.duration}m`}</span>
                    </span>
                  </li>
                );
              })}
            </ol>
          ) : <EmptyState icon={ICONS.calendar} title="Nothing scheduled today" body="Add a class, study block or reminder and it will show up here." action="Add an event" onAction={() => useApp.setState({ page: "schedule" })} />}
        </section>

        <section className="a-progress card rise d5" aria-label="Focus this week" style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <div className="card-head"><CardTitle idx="02">Focus this week</CardTitle>{!s.focusStart && <button type="button" className="btn btn-link" onClick={() => { s.startFocus(); playSound("focus"); }}>Start session</button>}</div>
          {s.focusStart ? (
            <div className="row" style={{ justifyContent: "space-between", gap: 16, padding: "14px 16px", borderRadius: 8, background: "var(--a-soft)", border: "1px solid var(--a)" }}>
              <div className="stack" style={{ gap: 2 }}><span className="eyebrow" style={{ color: "var(--a-ink)" }}>Session in progress</span><span className="num" style={{ fontSize: 30 }}>{String(Math.floor(elapsed / 60)).padStart(2, "0")}:{String(elapsed % 60).padStart(2, "0")}</span></div>
              <button type="button" className="btn-primary" onClick={() => { const m = s.stopFocus(); s.flash(`Session saved · ${m} min`); }}>End session</button>
            </div>
          ) : hasFocus ? (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 12 }}>
                {[["Today", (hours[ti] * ez).toFixed(1), "h"], ["Streak", String(Math.round(streak * ez)), streak === 1 ? "day" : "days"], ["Week", (hours.reduce((a, b) => a + b, 0) * ez).toFixed(1), "h"]].map(([l, v, u]) => (
                  <div key={l} className="stack" style={{ gap: 4 }}><span className="eyebrow">{l}</span><span><span className="num" style={{ fontSize: 24 }}>{v}</span> <span className="sub">{u}</span></span></div>
                ))}
              </div>
              <div role="img" aria-label="Daily focus hours this week" style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", gap: 8, alignItems: "end", height: 120 }}>
                {hours.map((h, i) => (
                  <div key={i} className="stack" style={{ alignItems: "center", gap: 6, height: "100%", justifyContent: "flex-end" }}>
                    <span className="num" style={{ fontSize: 10.5, color: i === ti ? "var(--a-ink)" : "var(--t3)" }}>{i <= ti ? (h * ez).toFixed(1) : ""}</span>
                    <div style={{ width: "100%", maxWidth: 28, height: `${Math.max(3, (h / wmax) * 78 * ez)}%`, borderRadius: "4px 4px 2px 2px", background: i === ti ? "var(--a)" : i > ti ? "rgba(var(--ink),.05)" : "rgba(var(--ink),.14)" }} />
                    <span style={{ fontSize: 11, color: i === ti ? "var(--t1)" : "var(--t3)" }}>{DAY_SHORT[i][0]}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <EmptyState icon={ICONS.clock} title="No focus sessions yet" body="Start a session and your hours, streak and weekly chart will appear here." action="Start your first session" onAction={() => { s.startFocus(); playSound("focus"); }} />}
        </section>
      </div>

      <div className="col col-center">
        {showBrief && !booting && <BriefCard key={brief.text} title={brief.title} text={brief.text} chips={brief.chips} />}
        <section className="a-hero card rise d1" aria-label={`${name} assistant`} style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <div className="card-head">
            <div className="row" style={{ gap: 10 }}><CardTitle>{name}</CardTitle><span className="chip"><span className="breathe" style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--a)" }} />{{ idle: "Online", listening: "Listening", thinking: "Thinking", speaking: "Speaking" }[s.orb]}</span></div>
            <button type="button" className="btn btn-link hide-sm" onClick={() => useApp.setState({ page: "settings" })}>Customise core</button>
          </div>
          <ParticleCore {...coreProps} hud bootLabel={booting ? name : null} maxWidth={500}
            readouts={{ tl: MODE_LABEL[s.mode].toUpperCase(), tr: new Date().toTimeString().slice(0, 5), bl: s.settings.shape.toUpperCase(), br: { idle: "STANDBY", listening: "LISTENING", thinking: "PROCESSING", speaking: "RESPONDING" }[s.orb] }} />
          <StatusLine />
          <Composer id="home-cmd" />
        </section>
      </div>

      <div className="col col-right">
        {!s.startHidden && (
          <section className="a-start card rise d2" aria-label="Get started" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div className="card-head"><CardTitle idx="00">Get started</CardTitle><span className="sub num">{startDone} of 5</span></div>
            <div style={{ height: 4, borderRadius: 4, background: "rgba(var(--ink),.07)" }}><div style={{ height: 4, borderRadius: 4, width: `${startDone * 20}%`, background: "var(--a)", transition: "width .5s" }} /></div>
            <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
              {start.map((x) => (
                <li key={x.label}>
                  <button type="button" className="btn list-btn" style={{ minHeight: 44, margin: "0 -8px", width: "calc(100% + 16px)" }} onClick={x.run}>
                    <span className={`check round ${x.done ? "on pop" : ""}`}>{x.done && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#08090A" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={ICONS.check} /></svg>}</span>
                    <span style={{ flex: 1, fontSize: 13.5, color: x.done ? "var(--t3)" : "var(--t1)", textDecoration: x.done ? "line-through" : "none" }}>{x.label}</span>
                    {!x.done && <span aria-hidden="true" style={{ color: "var(--t3)" }}>→</span>}
                  </button>
                </li>
              ))}
            </ul>
            {startDone === 5 && <button type="button" className="btn btn-ghost" onClick={() => useApp.setState({ startHidden: true })}>You’re all set · Hide this</button>}
          </section>
        )}

        <section className="a-tasks card rise d3" aria-label="Tasks" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="card-head"><CardTitle idx="03">Tasks</CardTitle><button type="button" className="btn btn-link" onClick={() => useApp.setState({ page: "tasks" })}>View all ({s.tasks.length})</button></div>
          {s.tasks.length ? (
            <>
              <div style={{ height: 4, borderRadius: 4, background: "rgba(var(--ink),.07)" }}><div style={{ height: 4, borderRadius: 4, width: `${(doneCount / s.tasks.length) * 100 * ez}%`, background: "var(--a)" }} /></div>
              <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>{tasks.map((t) => <li key={t.id}><TaskRow t={t} /></li>)}</ul>
            </>
          ) : <EmptyState icon={ICONS.tasks} title="No tasks yet" body={`Add your first task, or ask ${name} to help plan your week.`} action="Add a task" onAction={() => useApp.setState({ page: "tasks" })} />}
        </section>

        <section className="a-chat card rise d4" aria-label="Recent conversation" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card-head"><CardTitle idx="04">Recent conversation</CardTitle><button type="button" className="btn btn-link" onClick={() => useApp.setState({ page: "chat" })}>Open chat</button></div>
          <Messages limit={3} emptyText={`No messages yet. Say hello to ${name} from the message box.`} />
        </section>
      </div>
    </div>
  );
}
