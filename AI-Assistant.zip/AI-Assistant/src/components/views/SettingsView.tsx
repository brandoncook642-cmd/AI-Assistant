"use client";
import { useEffect, useState } from "react";
import { useApp } from "@/lib/store";
import { isConfigured, testConnection, AiError } from "@/lib/ai/client";
import { listVoices, speak } from "@/lib/speech";
import { playSound, type SoundName } from "@/lib/sound";
import { ACCENTS, SHAPES } from "@/lib/theme";
import type { Effects, Provider, ThemeChoice } from "@/lib/types";
import { setCoreShape } from "../core/coreState";
import { CardTitle, Icon, ICONS, Segmented, SettingRow, Switch } from "../ui";

const CLAUDE_MODELS = [
  { id: "claude-haiku-5-5", label: "Haiku", desc: "Fastest, lowest cost" },
  { id: "claude-sonnet-5-5", label: "Sonnet", desc: "Balanced — recommended" },
  { id: "claude-opus-5-5", label: "Opus", desc: "Most capable" },
];

const PROVIDERS: { id: Provider; label: string; desc: string }[] = [
  { id: "claude", label: "Claude", desc: "Your Anthropic API key" },
  { id: "ollama", label: "Ollama", desc: "Free, runs on your computer" },
  { id: "custom", label: "Custom", desc: "Any OpenAI-compatible API" },
];

export function ProviderPicker() {
  const provider = useApp((s) => s.settings.provider);
  const update = useApp((s) => s.updateSettings);
  return (
    <div role="group" aria-label="AI provider" style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 6 }}>
      {PROVIDERS.map((p) => {
        const on = provider === p.id;
        return (
          <button key={p.id} type="button" className="btn" aria-pressed={on} onClick={() => update({ provider: p.id })}
            style={{ minHeight: 64, display: "flex", flexDirection: "column", alignItems: "flex-start", justifyContent: "center", gap: 3, padding: "10px 12px", borderRadius: 8, border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.1)"}`, background: on ? "var(--a-soft)" : "transparent", color: "var(--t1)", font: "inherit", textAlign: "left", cursor: "pointer" }}>
            <span style={{ fontSize: 13.5, fontWeight: 500 }}>{p.label}</span>
            <span style={{ fontSize: 11.5, color: "var(--t3)" }}>{p.desc}</span>
          </button>
        );
      })}
    </div>
  );
}

export function KeyFields() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const [visible, setVisible] = useState(false);
  const p = s.provider;
  return (
    <>
      {p !== "ollama" && (
        <div className="stack" style={{ gap: 6 }}>
          <label htmlFor="api-key" className="label">{p === "claude" ? "Anthropic API key" : "API key"}</label>
          <div className="row" style={{ gap: 6 }}>
            <input id="api-key" className="input mono" type={visible ? "text" : "password"} autoComplete="off" spellCheck={false}
              value={s.apiKeys[p]} placeholder={p === "claude" ? "sk-ant-…" : "Paste your key"}
              onChange={(e) => update({ apiKeys: { ...s.apiKeys, [p]: e.target.value } })} />
            <button type="button" className="btn btn-icon" style={{ width: 42, height: 42, border: "1px solid rgba(var(--ink),.1)" }} aria-label={visible ? "Hide key" : "Show key"} onClick={() => setVisible(!visible)}>
              <Icon d={visible ? ICONS.eyeOff : ICONS.eye} size={16} />
            </button>
          </div>
          <span className="sub" style={{ lineHeight: 1.5 }}>{p === "claude" ? "Create one at console.anthropic.com, and set a monthly spending limit there." : "The key for your OpenAI-compatible provider."}</span>
        </div>
      )}
      {p !== "claude" && (
        <div className="stack" style={{ gap: 6 }}>
          <label htmlFor="ai-url" className="label">{p === "ollama" ? "Ollama server address" : "API base URL"}</label>
          <input id="ai-url" className="input mono" type="url" spellCheck={false} value={s.urls[p]} onChange={(e) => update({ urls: { ...s.urls, [p]: e.target.value } })} />
        </div>
      )}
    </>
  );
}

function AiCard() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const flash = useApp((st) => st.flash);
  const p = s.provider;
  const configured = isConfigured(s);
  // A test result only applies to the exact settings it was run with.
  const sig = JSON.stringify([p, s.apiKeys, s.urls, s.models]);
  const [result, setResult] = useState<{ sig: string; status: "testing" | "ok" | "bad"; detail: string } | null>(null);
  const status = result && result.sig === sig ? result.status : "idle";
  const detail = result && result.sig === sig ? result.detail : "";
  const test = async () => {
    setResult({ sig, status: "testing", detail: "" });
    try { await testConnection(s); setResult({ sig, status: "ok", detail: "" }); flash("Connected"); }
    catch (e) { setResult({ sig, status: "bad", detail: e instanceof AiError ? e.message : "Connection failed." }); }
  };
  const dot = status === "bad" ? "#FF6B5A" : status === "ok" ? "var(--a)" : configured ? "var(--t2)" : "var(--t3)";
  const label = { idle: configured ? "Not tested" : "Not connected", testing: "Testing…", ok: "Connected", bad: "Failed" }[status];
  return (
    <section className="card" aria-label="AI connection" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="card-head"><CardTitle>AI connection</CardTitle><span className="ai-status" style={{ color: dot }}><span style={{ width: 7, height: 7, borderRadius: "50%", background: dot }} />{label}</span></div>
      <ProviderPicker />
      <KeyFields />
      <div className="stack" style={{ gap: 6 }}>
        <span className="label">Model</span>
        {p === "claude" ? (
          <div role="radiogroup" aria-label="Model" className="stack" style={{ gap: 4 }}>
            {CLAUDE_MODELS.map((m) => {
              const on = s.models.claude === m.id;
              return (
                <button key={m.id} type="button" role="radio" aria-checked={on} className="btn" onClick={() => update({ models: { ...s.models, claude: m.id } })}
                  style={{ minHeight: 44, display: "flex", alignItems: "center", gap: 10, padding: "0 12px", borderRadius: 8, border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.08)"}`, background: on ? "var(--a-soft)" : "transparent", font: "inherit", textAlign: "left", cursor: "pointer" }}>
                  <span className="vdot" style={{ borderColor: on ? "var(--a)" : "rgba(var(--ink),.3)", background: on ? "var(--a)" : "transparent" }} />
                  <span style={{ flex: 1, fontSize: 13.5, color: "var(--t1)" }}>{m.label}</span>
                  <span style={{ fontSize: 12, color: "var(--t3)" }}>{m.desc}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <input aria-label="Model name" className="input mono" spellCheck={false} value={s.models[p]} placeholder={p === "ollama" ? "e.g. qwen2.5:7b" : "e.g. gpt-4o-mini"}
            onChange={(e) => update({ models: { ...s.models, [p]: e.target.value } })} />
        )}
      </div>
      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
        <button type="button" className="btn btn-ghost" disabled={!configured || status === "testing"} onClick={() => void test()}>Test connection</button>
        {p !== "ollama" && s.apiKeys[p] && <button type="button" className="btn btn-ghost" style={{ color: "#FF6B5A", borderColor: "rgba(255,107,90,.3)" }} onClick={() => { update({ apiKeys: { ...s.apiKeys, [p]: "" } }); flash("Key removed"); }}>Remove key</button>}
      </div>
      {detail && <span role="alert" style={{ fontSize: 13, color: "#FF6B5A", lineHeight: 1.5 }}>{detail}</span>}
      <div className="row" style={{ gap: 10, alignItems: "flex-start", padding: "10px 12px", borderRadius: 8, background: "rgba(var(--ink),.03)", fontSize: 12.5, lineHeight: 1.5, color: "var(--t2)" }}>
        <span style={{ flex: "none", marginTop: 1 }}><Icon d={ICONS.shield} size={16} /></span>
        <span>{p === "ollama" ? "Everything stays on your computer. Ollama must be running, with OLLAMA_ORIGINS allowing this site." : "Your key is stored only in this browser and sent straight to the provider. It never touches this app’s servers."}</span>
      </div>
    </section>
  );
}

function VoiceCard() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  useEffect(() => {
    const load = () => setVoices(listVoices());
    load();
    if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.onvoiceschanged = load;
  }, []);
  const sorted = [...voices.filter((v) => /^en/i.test(v.lang)), ...voices.filter((v) => !/^en/i.test(v.lang))].slice(0, 60);
  const opts = [{ voiceURI: "", name: "System default", lang: "", localService: true }, ...sorted];
  const langs = [["en-NZ", "English (NZ)"], ["en-AU", "English (AU)"], ["en-GB", "English (UK)"], ["en-US", "English (US)"], ["mi-NZ", "Māori"], ["es-ES", "Spanish"], ["fr-FR", "French"], ["ja-JP", "Japanese"]];
  return (
    <section className="card" aria-label="Voice" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="card-head"><CardTitle>Voice</CardTitle><span className="sub">{voices.length} voices on this device</span></div>
      <div className="stack" style={{ gap: 6 }}>
        <span id="voice-lbl" className="label">Reply voice</span>
        <div role="radiogroup" aria-labelledby="voice-lbl" className="voice-list">
          {opts.map((v) => {
            const on = s.voiceURI === v.voiceURI;
            return (
              <button key={v.voiceURI || "default"} type="button" role="radio" aria-checked={on} className="btn voice-opt"
                style={{ background: on ? "var(--a-soft)" : "transparent", borderColor: on ? "var(--a)" : "transparent" }}
                onClick={() => { update({ voiceURI: v.voiceURI }); setTimeout(() => speak("Hello"), 30); }}>
                <span className="vdot" style={{ background: on ? "var(--a)" : "transparent", borderColor: on ? "var(--a)" : "rgba(var(--ink),.3)" }} />
                <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v.name}</span>
                <span className="sub" style={{ fontSize: 11.5 }}>{v.lang}{v.localService ? "" : " · online"}</span>
              </button>
            );
          })}
        </div>
      </div>
      {([["voiceRate", "Speed", 0.6, 1.6], ["voicePitch", "Pitch", 0.6, 1.5]] as const).map(([k, l, min, max]) => (
        <div key={k} className="stack" style={{ gap: 6 }}>
          <label htmlFor={k} className="row label" style={{ justifyContent: "space-between" }}><span>{l}</span><span className="num" style={{ color: "var(--t1)" }}>{s[k].toFixed(2)}×</span></label>
          <input id={k} className="range" type="range" min={min} max={max} step={0.05} value={s[k]} onChange={(e) => update({ [k]: Number(e.target.value) })} />
        </div>
      ))}
      <div className="stack" style={{ gap: 6 }}>
        <span id="stt-lbl" className="label">Speech recognition language</span>
        <div role="radiogroup" aria-labelledby="stt-lbl" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(130px, 1fr))", gap: 4 }}>
          {langs.map(([v, l]) => {
            const on = s.speechLang === v;
            return <button key={v} type="button" role="radio" aria-checked={on} className="btn" onClick={() => update({ speechLang: v })}
              style={{ minHeight: 36, padding: "0 10px", borderRadius: 6, border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.08)"}`, background: on ? "var(--a-soft)" : "transparent", color: on ? "var(--t1)" : "var(--t2)", font: "inherit", fontSize: 12.5, textAlign: "left", cursor: "pointer" }}>{l}</button>;
          })}
        </div>
      </div>
      <SettingRow title="Spoken replies" desc="Read every answer aloud"><Switch label="Spoken replies" checked={s.spokenReplies} onChange={(v) => update({ spokenReplies: v })} /></SettingRow>
      <button type="button" className="btn btn-ghost" onClick={() => speak(`Hi${s.userName ? " " + s.userName : ""}, this is how I will sound.`)}><Icon d={ICONS.play} size={12} fill />Preview voice</button>
    </section>
  );
}

function AppearanceCard() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const setCustomised = () => useApp.setState({ customised: true });
  const pickShape = (name: string) => { update({ shape: name }); setCoreShape(name); setCustomised(); };
  return (
    <AppearanceBody s={s} update={update} setCustomised={setCustomised} pickShape={pickShape} />
  );
}

function ShapeGrid({ group, current, onPick }: { group: "signature" | "classic"; current: string; onPick: (n: string) => void }) {
  return (
    <div role="group" aria-label={`${group} core shapes`} style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 6 }}>
      {SHAPES.filter((x) => x.group === group).map((sh) => {
        const on = current === sh.name;
        return (
          <button key={sh.name} type="button" className="btn shape-btn" aria-pressed={on} onClick={() => onPick(sh.name)}
            style={{ minHeight: 64, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, background: on ? "var(--a-soft)" : "rgba(var(--ink),.02)", border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.07)"}`, borderRadius: 8, color: on ? "var(--a-ink)" : "var(--t2)", font: "inherit", fontSize: 11.5, cursor: "pointer" }}>
            <Icon d={sh.icon} size={22} stroke={1.4} />{sh.name}
          </button>
        );
      })}
    </div>
  );
}

type Settings = ReturnType<typeof useApp.getState>["settings"];
function AppearanceBody({ s, update, setCustomised, pickShape }: { s: Settings; update: (p: Partial<Settings>) => void; setCustomised: () => void; pickShape: (n: string) => void }) {
  return (
    <section className="card" aria-label="Appearance" style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <CardTitle>Appearance</CardTitle>
      <div className="stack" style={{ gap: 10 }}><span className="eyebrow">Theme</span>
        <Segmented full label="Theme" value={s.theme} onChange={(v: ThemeChoice) => update({ theme: v })} options={[{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }, { value: "system", label: "System" }]} />
      </div>
      <div className="stack" style={{ gap: 10 }}><span className="eyebrow">Accent</span>
        <div role="group" aria-label="Accent colour" className="row" style={{ flexWrap: "wrap", gap: 8 }}>
          {ACCENTS.map((a) => {
            const on = s.accent === a.id;
            return <button key={a.id} type="button" className="swatch" aria-pressed={on} aria-label={a.label} title={a.label} onClick={() => { update({ accent: a.id }); setCustomised(); }}
              style={{ background: `linear-gradient(135deg, ${a.a}, ${a.a2})`, border: `2px solid ${on ? "var(--t1)" : "transparent"}`, boxShadow: `0 0 0 2px ${on ? "var(--bg)" : "transparent"}` }} />;
          })}
          <label htmlFor="accent-custom" className="sr-only">Custom accent colour</label>
          <input id="accent-custom" className="color" type="color" value={s.customAccent} title="Custom colour" onChange={(e) => { update({ customAccent: e.target.value, accent: "custom" }); setCustomised(); }} />
        </div>
      </div>
      <div className="stack" style={{ gap: 10 }}><span className="eyebrow">Particle palette</span>
        <Segmented full label="Particle palette" value={s.palette} onChange={(v) => update({ palette: v })} options={[{ value: "duo", label: "Duo" }, { value: "mono", label: "Mono" }, { value: "spectrum", label: "Spectrum" }]} />
      </div>
      <SettingRow title="Core follows mode" desc="Focus turns it violet, Alert turns it amber"><Switch label="Core follows mode" checked={s.coreFollowsMode} onChange={(v) => update({ coreFollowsMode: v })} /></SettingRow>
      <div className="stack" style={{ gap: 8 }}><span className="eyebrow">Core · Signature</span><ShapeGrid group="signature" current={s.shape} onPick={pickShape} /></div>
      <div className="stack" style={{ gap: 8 }}><span className="eyebrow">Core · Classic</span><ShapeGrid group="classic" current={s.shape} onPick={pickShape} /></div>
      {([["density", "Density", 0.15, 1, (v: number) => `${Math.round(v * 7000).toLocaleString()} pts`], ["particleSize", "Particle size", 0.5, 2.2, (v: number) => `${v.toFixed(2)}×`], ["spin", "Spin speed", 0, 3, (v: number) => `${v.toFixed(2)}×`]] as const).map(([k, l, min, max, fmt]) => (
        <div key={k} className="stack" style={{ gap: 6 }}>
          <label htmlFor={`core-${k}`} className="row label" style={{ justifyContent: "space-between" }}><span>{l}</span><span className="num" style={{ color: "var(--t1)" }}>{fmt(s[k])}</span></label>
          <input id={`core-${k}`} className="range" type="range" min={min} max={max} step={0.01} value={s[k]} onChange={(e) => update({ [k]: Number(e.target.value) })} />
        </div>
      ))}
    </section>
  );
}

function EffectsCard({ onReplay }: { onReplay: () => void }) {
  const fx = useApp((st) => st.settings.effects);
  const update = useApp((st) => st.updateSettings);
  const rows: [keyof Effects, string, string][] = [
    ["bloom", "Bloom glow", "Soft light around each particle"], ["trails", "Particle trails", "Motion streaks while thinking and morphing"],
    ["bgCore", "Background core", "A faint giant swarm behind every page"], ["cursor", "Cursor reactive", "The core leans towards your pointer"],
    ["tilt", "3D card tilt", "Cards tilt and shine as you hover"], ["mesh", "Animated background", "Slow-moving colour light behind everything"],
  ];
  return (
    <section className="card" aria-label="Effects" style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <div className="card-head" style={{ marginBottom: 8 }}><CardTitle>Effects</CardTitle><button type="button" className="btn btn-ghost" style={{ minHeight: 32 }} onClick={onReplay}>Replay startup</button></div>
      {rows.map(([k, l, d]) => <SettingRow key={k} title={l} desc={d}><Switch label={l} checked={fx[k]} onChange={(v) => update({ effects: { ...fx, [k]: v } })} /></SettingRow>)}
    </section>
  );
}

function SoundCard() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const demos: [string, SoundName][] = [["Listen", "listenOn"], ["Send", "send"], ["Reply", "reply"], ["Task done", "done"], ["Reminder", "bell"], ["Mode", "whoosh"], ["Startup", "boot"]];
  return (
    <section className="card" aria-label="Sound" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div className="card-head"><CardTitle>Sound</CardTitle><Switch label="Interface sounds" checked={s.sound} onChange={(v) => { update({ sound: v }); if (v) setTimeout(() => playSound("tick"), 30); }} /></div>
      <div className="stack" style={{ gap: 6 }}>
        <label htmlFor="vol" className="row label" style={{ justifyContent: "space-between" }}><span>Volume</span><span className="num" style={{ color: "var(--t1)" }}>{Math.round(s.volume * 100)}%</span></label>
        <input id="vol" className="range" type="range" min={0} max={1} step={0.05} value={s.volume} onChange={(e) => update({ volume: Number(e.target.value) })} />
      </div>
      <div className="row" style={{ flexWrap: "wrap", gap: 6 }}>
        {demos.map(([l, n]) => <button key={n} type="button" className="btn btn-ghost" style={{ minHeight: 34, borderRadius: 999, fontSize: 12.5 }} onClick={() => playSound(n)}><Icon d={ICONS.play} size={10} fill />{l}</button>)}
      </div>
    </section>
  );
}

function NotificationsCard() {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const [desktop, setDesktop] = useState<string>(() => (typeof Notification !== "undefined" ? Notification.permission : "unsupported"));
  return (
    <section className="card" aria-label="Notification settings" style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <CardTitle>Notifications</CardTitle>
      <SettingRow title="Event reminders" desc="A heads-up before each event starts"><Switch label="Event reminders" checked={s.remindEvents} onChange={(v) => update({ remindEvents: v })} /></SettingRow>
      <SettingRow title="Task nudges" desc="A nudge for tasks due today when you open the app"><Switch label="Task nudges" checked={s.nudgeTasks} onChange={(v) => update({ nudgeTasks: v })} /></SettingRow>
      <SettingRow title="Remind me before events">
        <Segmented label="Reminder lead time" value={s.leadMinutes} onChange={(v) => update({ leadMinutes: v })} options={[5, 10, 15, 30].map((v) => ({ value: v, label: `${v} min` }))} />
      </SettingRow>
      <div className="row" style={{ gap: 8, flexWrap: "wrap", paddingTop: 10, borderTop: "1px solid rgba(var(--ink),.05)" }}>
        <button type="button" className="btn btn-ghost" disabled={desktop === "unsupported" || desktop === "granted"}
          onClick={() => Notification.requestPermission().then(setDesktop)}>
          {desktop === "granted" ? "Desktop notifications on" : desktop === "denied" ? "Desktop notifications blocked" : desktop === "unsupported" ? "Not supported here" : "Enable desktop notifications"}
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => { useApp.getState().notify({ kind: "info", title: "Test reminder", body: "This is how reminders will look." }); playSound("bell"); }}>Send a test</button>
      </div>
    </section>
  );
}

function DataCard() {
  const reset = useApp((st) => st.resetAll);
  const exportData = () => {
    const { settings, tasks, events, messages, sessions } = useApp.getState();
    const safe = { ...settings, apiKeys: { claude: "", custom: "" } };
    const blob = new Blob([JSON.stringify({ settings: safe, tasks, events, messages, sessions }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "assistant-data.json";
    a.click();
    URL.revokeObjectURL(a.href);
  };
  return (
    <section className="card" aria-label="Your data" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <CardTitle>Your data</CardTitle>
      <p className="sub" style={{ margin: 0, lineHeight: 1.5 }}>Everything is saved in this browser. Export a copy, or start over.</p>
      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
        <button type="button" className="btn btn-ghost" onClick={exportData}>Export data</button>
        <button type="button" className="btn btn-ghost" style={{ color: "#FF6B5A", borderColor: "rgba(255,107,90,.3)" }}
          onClick={() => { if (window.confirm("Delete all tasks, events, chats and settings on this device?")) reset(); }}>Reset everything</button>
      </div>
    </section>
  );
}

export default function SettingsView({ onReplay }: { onReplay: () => void }) {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  return (
    <div className="page-even page-in">
      <div className="stack-col">
        <section className="card" aria-label="Assistant settings" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <CardTitle>Assistant</CardTitle>
          <div className="stack" style={{ gap: 6 }}><label htmlFor="set-ai" className="label">Assistant name</label><input id="set-ai" className="input" placeholder="Assistant" value={s.assistantName} onChange={(e) => update({ assistantName: e.target.value })} /></div>
          <div className="stack" style={{ gap: 6 }}><label htmlFor="set-name" className="label">Your name</label><input id="set-name" className="input" placeholder="Your name" value={s.userName} onChange={(e) => update({ userName: e.target.value })} /></div>
        </section>
        <AiCard />
        <VoiceCard />
        <NotificationsCard />
      </div>
      <div className="stack-col">
        <AppearanceCard />
        <EffectsCard onReplay={onReplay} />
        <SoundCard />
        <DataCard />
      </div>
    </div>
  );
}
