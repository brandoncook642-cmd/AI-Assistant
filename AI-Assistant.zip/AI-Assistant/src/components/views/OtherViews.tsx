"use client";
// Chat, Tasks, Schedule and Code pages.
import { useMemo, useState } from "react";
import { useApp } from "@/lib/store";
import { chat, isConfigured, AiError } from "@/lib/ai/client";
import { DAY_LONG, DAY_SHORT, fmtTime, minutesNow, mondayOf, todayIndex } from "@/lib/time";
import type { Due, EventKind } from "@/lib/types";
import { send } from "@/lib/assistant";
import ParticleCore from "../core/ParticleCore";
import { Composer, Messages, StatusLine } from "../assistant/Conversation";
import { CardTitle, EmptyState, Icon, ICONS, Segmented } from "../ui";
import { TaskRow } from "./HomeView";

type CoreProps = { coreColour: string; glow: number; glowScale: number; rings: boolean };

/* ---------------- Chat ---------------- */
export function ChatView({ coreProps }: { coreProps: CoreProps }) {
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  const count = useApp((s) => s.messages.length);
  const prompts = ["What should I work on next?", "Explain recursion simply", "Plan my study for tomorrow", "Add a task to review my notes"];
  return (
    <div className="page-split page-in">
      <section className="card" aria-label="Conversation" style={{ display: "flex", flexDirection: "column", gap: 16, minHeight: 640 }}>
        <div className="card-head"><CardTitle>Conversation</CardTitle>
          <span className="row" style={{ gap: 8 }}><span className="sub num">{count} messages</span>{count > 0 && <button type="button" className="btn btn-link" onClick={() => useApp.getState().clearChat()}>Clear</button>}</span>
        </div>
        <div className="stack" style={{ flex: 1, justifyContent: "flex-end", maxHeight: "62vh", overflowY: "auto" }}><Messages emptyText={`Ask ${name} anything — or try one of the suggestions.`} /></div>
        <Composer id="chat-cmd" quick={false} compact />
      </section>
      <aside className="stack-col">
        <section className="card" aria-label={`${name} status`} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card-head"><CardTitle>{name}</CardTitle></div>
          <ParticleCore {...coreProps} maxWidth={280} />
          <StatusLine />
        </section>
        <section className="card" aria-label="Suggestions" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <CardTitle>Try asking</CardTitle>
          {prompts.map((p) => (
            <button key={p} type="button" className="btn btn-ghost" style={{ justifyContent: "space-between", minHeight: 44, textAlign: "left" }} onClick={() => void send(p)}>{p}<span aria-hidden="true" style={{ color: "var(--t3)" }}>→</span></button>
          ))}
        </section>
      </aside>
    </div>
  );
}

/* ---------------- Tasks ---------------- */
export function TasksView() {
  const { tasks, addTask, removeTask, clearDone, flash } = useApp();
  const name = useApp((s) => s.settings.assistantName) || "Assistant";
  const [text, setText] = useState("");
  const [due, setDue] = useState<Due>("Today");
  const [priority, setPriority] = useState(false);
  const [filter, setFilter] = useState<"All" | "Active" | "Done">("All");
  const active = tasks.filter((t) => !t.done).length;
  const done = tasks.length - active;
  const rank = { Today: 0, Tomorrow: 1, "This week": 2 };
  const list = [...tasks].sort((a, b) => Number(a.done) - Number(b.done) || Number(b.priority) - Number(a.priority) || rank[a.due] - rank[b.due])
    .filter((t) => filter === "All" || (filter === "Active" ? !t.done : t.done));
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  return (
    <div className="page-split page-in">
      <section className="card" aria-label="All tasks" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <form className="row" style={{ flexWrap: "wrap", gap: 8 }} onSubmit={(e) => { e.preventDefault(); if (addTask(text, due, priority)) { setText(""); setPriority(false); flash("Task added"); } }}>
          <label htmlFor="new-task" className="sr-only">New task</label>
          <div className="composer" style={{ flex: "1 1 260px", padding: "4px 4px 4px 10px", color: "var(--t3)" }}>
            <Icon d={ICONS.plus} />
            <input id="new-task" autoComplete="off" value={text} onChange={(e) => setText(e.target.value)} placeholder="Add a task…" style={{ flex: 1, minWidth: 0, height: 40, padding: "0 8px", background: "transparent", border: 0, color: "var(--t1)", font: "inherit", fontSize: 14, outline: "none" }} />
          </div>
          <Segmented label="Due" value={due} onChange={setDue} options={(["Today", "Tomorrow", "This week"] as Due[]).map((d) => ({ value: d, label: d }))} />
          <button type="button" className="btn btn-ghost" aria-pressed={priority} onClick={() => setPriority(!priority)} style={{ minHeight: 46, ...(priority ? { background: "var(--a-soft)", borderColor: "var(--a)", color: "var(--a-ink)" } : {}) }}>Priority</button>
          <button type="submit" className="btn-primary" style={{ minHeight: 46 }}>Add</button>
        </form>
        <div className="row" style={{ justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <Segmented label="Filter tasks" value={filter} onChange={setFilter} options={[{ value: "All", label: `All ${tasks.length}` }, { value: "Active", label: `Active ${active}` }, { value: "Done", label: `Done ${done}` }]} />
          {done > 0 && <button type="button" className="btn btn-link" onClick={() => { clearDone(); flash("Completed tasks cleared"); }}>Clear completed</button>}
        </div>
        {list.length ? (
          <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
            {list.map((t) => (
              <li key={t.id} className="row" style={{ gap: 4, borderBottom: "1px solid rgba(var(--ink),.05)", paddingLeft: 10 }}>
                <div style={{ flex: 1, minWidth: 0 }}><TaskRow t={t} /></div>
                <button type="button" className="btn btn-icon" aria-label={`Delete ${t.label}`} onClick={() => { removeTask(t.id); flash("Task deleted"); }}><Icon d={ICONS.trash} size={16} /></button>
              </li>
            ))}
          </ul>
        ) : <EmptyState icon={ICONS.tasks} title="Nothing here" body={`Add a task above, or ask ${name} to plan your day.`} />}
      </section>
      <aside className="stack-col">
        <section className="card" aria-label="Progress" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <CardTitle>Progress</CardTitle>
          <div className="row" style={{ gap: 18 }}>
            <svg width="96" height="96" viewBox="0 0 100 100" role="img" aria-label={`${pct} percent complete`}>
              <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(var(--ink),.08)" strokeWidth="8" />
              <circle cx="50" cy="50" r="42" fill="none" stroke="var(--a)" strokeWidth="8" strokeLinecap="round" strokeDasharray={`${(pct / 100) * 263.9} 264`} transform="rotate(-90 50 50)" />
              <text x="50" y="56" textAnchor="middle" fill="var(--t1)" style={{ fontFamily: "var(--font-mono)", fontSize: 20 }}>{pct}%</text>
            </svg>
            <div className="stack" style={{ gap: 8, fontSize: 13, color: "var(--t2)" }}>
              <span><span className="num" style={{ color: "var(--t1)" }}>{active}</span> active</span>
              <span><span className="num" style={{ color: "var(--t1)" }}>{done}</span> completed</span>
              <span><span className="num" style={{ color: "var(--a-ink)" }}>{tasks.filter((t) => t.priority && !t.done).length}</span> priority</span>
            </div>
          </div>
        </section>
        <section className="card" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <CardTitle>Tip</CardTitle>
          <p style={{ margin: 0, fontSize: 13, lineHeight: 1.55, color: "var(--t2)" }}>Press <span className="kbd">⌘K</span> and type “add task …”, or just tell {name} what you need to do.</p>
        </section>
      </aside>
    </div>
  );
}

/* ---------------- Schedule ---------------- */
const KINDS: { id: EventKind; label: string; colour: string }[] = [
  { id: "class", label: "Class", colour: "var(--a)" },
  { id: "study", label: "Study", colour: "var(--a2)" },
  { id: "project", label: "Project", colour: "#FFB020" },
  { id: "check", label: "Check-in", colour: "#8E9497" },
];
const START = 8 * 60, SPAN = 14 * 60;

export function ScheduleView() {
  const { events, addEvent, removeEvent, flash } = useApp();
  const ti = todayIndex();
  const mins = minutesNow();
  const monday = mondayOf();
  const [form, setForm] = useState(false);
  const [title, setTitle] = useState("");
  const [day, setDay] = useState(ti);
  const [time, setTime] = useState("09:00");
  const [dur, setDur] = useState(60);
  const [kind, setKind] = useState<EventKind>("class");
  const colour = (k: EventKind) => KINDS.find((x) => x.id === k)!.colour;
  const submit = () => {
    const [h, m] = time.split(":").map(Number);
    if (addEvent({ title, day, start: (h || 9) * 60 + (m || 0), duration: dur, kind })) { setTitle(""); setForm(false); flash("Event added"); }
    else flash("Give the event a title");
  };
  return (
    <section className="card page-in" aria-label="Week schedule" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="card-head">
        <div className="row" style={{ gap: 12 }}><CardTitle>Week of {monday.toLocaleDateString(undefined, { day: "numeric", month: "long" })}</CardTitle>
          <button type="button" className="btn-primary" style={{ minHeight: 32, fontSize: 12.5, padding: "0 12px" }} onClick={() => setForm(!form)}>+ Add event</button></div>
        <div className="row" style={{ gap: 14, flexWrap: "wrap" }}>{KINDS.map((k) => <span key={k.id} className="row" style={{ gap: 6, fontSize: 12, color: "var(--t2)" }}><span style={{ width: 8, height: 8, borderRadius: 3, background: k.colour }} />{k.label}</span>)}</div>
      </div>
      {form && (
        <form className="row page-in" style={{ flexWrap: "wrap", gap: 10, alignItems: "flex-end", padding: 14, borderRadius: 8, background: "rgba(var(--ink),.03)", border: "1px solid rgba(var(--ink),.08)" }} onSubmit={(e) => { e.preventDefault(); submit(); }}>
          <div className="stack" style={{ flex: "1 1 220px", gap: 6 }}><label htmlFor="ev-title" className="label">Title</label><input id="ev-title" className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Networking class" /></div>
          <div className="stack" style={{ gap: 6 }}><span className="label">Day</span><Segmented label="Day" value={day} onChange={setDay} options={DAY_SHORT.map((d, i) => ({ value: i, label: d[0] }))} /></div>
          <div className="stack" style={{ gap: 6 }}><label htmlFor="ev-time" className="label">Start</label><input id="ev-time" className="input" type="time" value={time} onChange={(e) => setTime(e.target.value)} style={{ width: 120 }} /></div>
          <div className="stack" style={{ gap: 6 }}><span className="label">Length</span><Segmented label="Length" value={dur} onChange={setDur} options={[[30, "30m"], [60, "1h"], [90, "1.5h"], [120, "2h"]].map(([v, l]) => ({ value: v as number, label: l }))} /></div>
          <div className="stack" style={{ gap: 6 }}><span className="label">Type</span><Segmented label="Type" value={kind} onChange={setKind} options={KINDS.map((k) => ({ value: k.id, label: k.label }))} /></div>
          <button type="submit" className="btn-primary">Add</button>
        </form>
      )}
      <div style={{ position: "relative" }}>
        {events.length === 0 && !form && (
          <div style={{ position: "absolute", inset: "60px 0 0 52px", zIndex: 2, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ padding: "24px 28px", borderRadius: 12, background: "color-mix(in srgb, var(--pop) 92%, transparent)", border: "1px solid rgba(var(--ink),.08)" }}>
              <EmptyState icon={ICONS.calendar} title="Your week is empty" body="Add classes, study blocks and reminders — or ask the assistant to add them." action="Add your first event" onAction={() => setForm(true)} />
            </div>
          </div>
        )}
        <div className="week-grid">
          <div />
          {DAY_SHORT.map((d, i) => {
            const date = new Date(monday); date.setDate(monday.getDate() + i);
            return (
              <div key={d} className="stack" style={{ alignItems: "center", gap: 2, paddingBottom: 10 }}>
                <span style={{ fontSize: 12, color: i === ti ? "var(--t1)" : "var(--t3)" }}>{d}</span>
                <span className="num" style={{ width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "50%", background: i === ti ? "var(--a)" : "transparent", color: i === ti ? "#08090A" : "var(--t1c)", fontSize: 14 }}>{date.getDate()}</span>
              </div>
            );
          })}
          <div style={{ position: "relative", height: 640 }}>
            {[8, 10, 12, 14, 16, 18, 20, 22].map((h) => <span key={h} className="num" style={{ position: "absolute", top: `${((h * 60 - START) / SPAN) * 100}%`, right: 8, transform: "translateY(-50%)", fontSize: 11, color: "var(--t3)" }}>{String(h).padStart(2, "0")}:00</span>)}
          </div>
          {DAY_SHORT.map((d, i) => (
            <div key={d} style={{ position: "relative", height: 640, borderLeft: "1px solid rgba(var(--ink),.05)", background: i === ti ? "rgba(var(--ink),.02)" : "transparent", backgroundImage: "repeating-linear-gradient(180deg, rgba(var(--ink),.045) 0 1px, transparent 1px 91.43px)" }}>
              {events.filter((e) => e.day === i).map((e) => (
                <button key={e.id} type="button" title="Click to delete" onClick={() => { if (confirmDelete(e.title)) { removeEvent(e.id); flash("Event deleted"); } }}
                  style={{ position: "absolute", left: 4, right: 4, top: `${((e.start - START) / SPAN) * 100}%`, height: `${(e.duration / SPAN) * 100}%`, minHeight: 22, padding: "5px 7px", borderRadius: 6, border: 0, borderLeft: `3px solid ${colour(e.kind)}`, background: `color-mix(in srgb, ${colour(e.kind)} 12%, transparent)`, overflow: "hidden", display: "flex", flexDirection: "column", gap: 1, textAlign: "left", cursor: "pointer", font: "inherit" }}>
                  <span style={{ fontSize: 11.5, fontWeight: 500, color: "var(--t1)", lineHeight: 1.25 }}>{e.title}</span>
                  <span className="num" style={{ fontSize: 10.5, color: "var(--t2)" }}>{fmtTime(e.start)}–{fmtTime(e.start + e.duration)}</span>
                </button>
              ))}
              {i === ti && mins >= START && mins <= START + SPAN && <div aria-hidden="true" style={{ position: "absolute", left: -4, right: 0, top: `${((mins - START) / SPAN) * 100}%`, height: 2, background: "#FF6B5A" }} />}
            </div>
          ))}
        </div>
      </div>
      <div className="day-list">
        {DAY_LONG.map((d, i) => {
          const list = events.filter((e) => e.day === i).sort((a, b) => a.start - b.start);
          return (
            <div key={d} className="stack" style={{ gap: 6, padding: "10px 0", borderTop: "1px solid rgba(var(--ink),.06)" }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: i === ti ? "var(--t1)" : "var(--t3)" }}>{d}</span>
              {list.length ? list.map((e) => (
                <div key={e.id} className="row" style={{ gap: 10, padding: "8px 10px", borderRadius: 8, borderLeft: `3px solid ${colour(e.kind)}`, background: `color-mix(in srgb, ${colour(e.kind)} 10%, transparent)` }}>
                  <span className="num" style={{ fontSize: 12, color: "var(--t2)", minWidth: 44 }}>{fmtTime(e.start)}</span><span style={{ fontSize: 13.5 }}>{e.title}</span>
                </div>
              )) : <span className="sub">Nothing planned</span>}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function confirmDelete(title: string) {
  return typeof window !== "undefined" && window.confirm(`Delete “${title}”?`);
}

/* ---------------- Code ---------------- */
const SAMPLE = "def factorial(n):\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)\n\n\nprint(factorial(5))\n";

export function CodeView() {
  const settings = useApp((s) => s.settings);
  const name = settings.assistantName || "Assistant";
  const [code, setCode] = useState(SAMPLE);
  const [result, setResult] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const lang = useMemo(() => (/\bdef\s+\w+\s*\(|print\s*\(/.test(code) ? "Python" : /\bfunction\b|=>|\bconst\b/.test(code) ? "JavaScript" : "Code"), [code]);
  const lines = code.split("\n").filter((l) => l.trim()).length;

  const run = async (mode: "explain" | "bugs") => {
    if (!code.trim()) return;
    if (!isConfigured(settings)) { setResult(`Connect an AI in Settings → AI connection and ${name} will explain this code line by line.`); return; }
    setBusy(true); setResult(null);
    useApp.setState({ orb: "thinking" });
    try {
      const ask = mode === "explain"
        ? "Explain this code step by step for a student. Start with a one-sentence summary, then a short numbered walkthrough, then what it outputs."
        : "Review this code for bugs and edge cases. List each issue with a one-line fix. If there are none, say so and suggest edge cases to test.";
      const reply = await chat(settings, `You are ${name}, a patient coding tutor. Be clear and concise. Use plain text, numbered lists, and short code snippets only when needed.`,
        [{ role: "user", text: `${ask}\n\n\`\`\`${lang.toLowerCase()}\n${code}\n\`\`\`` }]);
      setResult(reply);
    } catch (e) {
      setResult(e instanceof AiError ? e.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
      useApp.setState({ orb: "idle" });
    }
  };

  return (
    <div className="page-even page-in">
      <section className="card" aria-label="Code input" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="card-head"><CardTitle>Your code</CardTitle><span className="row" style={{ gap: 8 }}><span className="chip">{lang}</span><span className="sub num">{lines} lines</span></span></div>
        <label htmlFor="code-in" className="sr-only">Code to explain</label>
        <textarea id="code-in" className="code" spellCheck={false} value={code} onChange={(e) => setCode(e.target.value)} />
        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void run("explain")}>Explain</button>
          <button type="button" className="btn btn-ghost" style={{ minHeight: 42 }} disabled={busy} onClick={() => void run("bugs")}>Find bugs</button>
          <button type="button" className="btn btn-link" style={{ marginLeft: "auto" }} onClick={() => { setCode(""); setResult(null); }}>Clear</button>
        </div>
      </section>
      <section className="card" aria-label={`${name}'s analysis`} aria-live="polite" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="card-head"><CardTitle>{name}’s analysis</CardTitle></div>
        {busy ? (
          <div className="stack" style={{ gap: 10 }}><div className="shimmer" style={{ height: 14, width: "70%" }} /><div className="shimmer" style={{ height: 14, width: "90%" }} /><div className="shimmer" style={{ height: 14, width: "55%" }} /></div>
        ) : result ? (
          <p className="bubble ai" style={{ maxWidth: "100%", fontSize: 14 }}>{result}</p>
        ) : <EmptyState icon={ICONS.code} title="Ready when you are" body="Paste code on the left and choose Explain or Find bugs." />}
      </section>
    </div>
  );
}
