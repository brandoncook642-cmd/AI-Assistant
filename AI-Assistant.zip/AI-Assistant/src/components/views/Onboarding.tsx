"use client";
// First-launch setup: names, look, interests, AI connection, schedule.
import { useState } from "react";
import { useApp } from "@/lib/store";
import { ACCENTS, SHAPES } from "@/lib/theme";
import { setCoreShape } from "../core/coreState";
import ParticleCore from "../core/ParticleCore";
import { Icon, ICONS } from "../ui";
import { KeyFields, ProviderPicker } from "./SettingsView";

const INTERESTS = ["Study", "Coding", "Projects", "Planning", "Reading", "Fitness"];

export default function Onboarding({ booting, coreProps, onDone }: { booting: boolean; coreProps: { coreColour: string; glow: number; glowScale: number; rings: boolean }; onDone: () => void }) {
  const s = useApp((st) => st.settings);
  const update = useApp((st) => st.updateSettings);
  const [step, setStep] = useState(0);
  const next = () => setStep((x) => Math.min(5, x + 1));
  const back = () => setStep((x) => Math.max(0, x - 1));

  const finish = () => {
    const app = useApp.getState();
    const name = app.settings.userName.trim();
    const ai = app.settings.assistantName.trim() || "your assistant";
    const ints = app.settings.interests;
    const tip = ints.includes("Coding") ? "paste some code on the Code page and I’ll explain it" : ints.includes("Study") ? "tell me what you’re studying and I’ll help you plan it" : "add a task and I’ll help you stay on top of it";
    if (!app.messages.length) app.addMessage("assistant", `Hi${name ? " " + name : ""}, I’m ${ai}. I’m set up and ready. To start, ${tip} — or just ask me anything.`);
    app.completeOnboarding();
    app.flash(`Welcome${name ? ", " + name : ""}!`);
    onDone();
  };

  const nav = (skip?: boolean) => (
    <div className="row" style={{ gap: 8, justifyContent: "center", marginTop: 4 }}>
      <button type="button" className="btn btn-ghost" style={{ minHeight: 42 }} onClick={back}>Back</button>
      {skip && <button type="button" className="btn btn-ghost" style={{ minHeight: 42 }} onClick={next}>Skip for now</button>}
      <button type="button" className="btn-primary" onClick={next}>Continue</button>
    </div>
  );

  return (
    <div className="stack" style={{ minHeight: "100vh", alignItems: "center", justifyContent: "center", padding: "32px 16px", gap: 8 }}>
      <ParticleCore {...coreProps} maxWidth={320} bootLabel={booting ? s.assistantName || "Assistant" : null} />
      {!booting && (
        <div className="onboard">
          <div className="row" style={{ gap: 6, justifyContent: "center" }}>
            {[0, 1, 2, 3, 4, 5].map((i) => <span key={i} style={{ width: i === step ? 22 : 6, height: 6, borderRadius: 3, background: i <= step ? "var(--a)" : "rgba(var(--ink),.15)", transition: "width .3s, background .3s" }} />)}
          </div>

          {step === 0 && (
            <div className="ob-step" key="0">
              <h2 className="ob-title">Hi, I’m {s.assistantName.trim() || "your new assistant"}.</h2>
              <p className="ob-body">Your personal assistant for study, code and planning. Let’s set things up — it takes about 30 seconds.</p>
              <div className="row" style={{ gap: 8, justifyContent: "center" }}>
                <button type="button" className="btn btn-ghost" style={{ minHeight: 42 }} onClick={finish}>Skip setup</button>
                <button type="button" className="btn-primary" onClick={next}>Get started</button>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="ob-step" key="1">
              <h2 className="ob-title">What should we call each other?</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12, textAlign: "left" }}>
                <div className="stack" style={{ gap: 6 }}><label htmlFor="ob-name" className="label">Your name</label><input id="ob-name" className="input ob-input" autoComplete="given-name" placeholder="e.g. Alex" value={s.userName} onChange={(e) => update({ userName: e.target.value })} /></div>
                <div className="stack" style={{ gap: 6 }}><label htmlFor="ob-ai" className="label">Assistant name</label><input id="ob-ai" className="input ob-input" placeholder="e.g. Atlas" value={s.assistantName} onChange={(e) => update({ assistantName: e.target.value })} /></div>
              </div>
              {nav()}
            </div>
          )}

          {step === 2 && (
            <div className="ob-step" key="2">
              <h2 className="ob-title">Make it yours</h2>
              <p className="ob-body">Pick a colour and a core. You can change these any time in Settings.</p>
              <div role="group" aria-label="Accent colour" className="row" style={{ flexWrap: "wrap", gap: 10, justifyContent: "center" }}>
                {ACCENTS.map((a) => {
                  const on = s.accent === a.id;
                  return <button key={a.id} type="button" className="swatch" aria-pressed={on} aria-label={a.label} onClick={() => update({ accent: a.id })}
                    style={{ width: 34, height: 34, background: `linear-gradient(135deg, ${a.a}, ${a.a2})`, border: `2px solid ${on ? "var(--t1)" : "transparent"}`, boxShadow: `0 0 0 2px ${on ? "var(--bg)" : "transparent"}` }} />;
                })}
              </div>
              <div role="group" aria-label="Core shape" style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 6 }}>
                {SHAPES.filter((x) => x.group === "signature").map((sh) => {
                  const on = s.shape === sh.name;
                  return (
                    <button key={sh.name} type="button" className="btn shape-btn" aria-pressed={on} onClick={() => { update({ shape: sh.name }); setCoreShape(sh.name); }}
                      style={{ minHeight: 58, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 5, background: on ? "var(--a-soft)" : "rgba(var(--ink),.02)", border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.07)"}`, borderRadius: 8, color: on ? "var(--a-ink)" : "var(--t2)", font: "inherit", fontSize: 11.5, cursor: "pointer" }}>
                      <Icon d={sh.icon} size={20} stroke={1.4} />{sh.name}
                    </button>
                  );
                })}
              </div>
              {nav()}
            </div>
          )}

          {step === 3 && (
            <div className="ob-step" key="3">
              <h2 className="ob-title">What will you use {s.assistantName.trim() || "me"} for?</h2>
              <p className="ob-body">Pick as many as you like. This shapes the suggestions you get.</p>
              <div role="group" aria-label="Interests" className="row" style={{ flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
                {INTERESTS.map((i) => {
                  const on = s.interests.includes(i);
                  return <button key={i} type="button" className="btn" aria-pressed={on} onClick={() => update({ interests: on ? s.interests.filter((x) => x !== i) : [...s.interests, i] })}
                    style={{ minHeight: 42, padding: "0 16px", borderRadius: 999, border: `1px solid ${on ? "var(--a)" : "rgba(var(--ink),.12)"}`, background: on ? "var(--a-soft)" : "transparent", color: on ? "var(--t1)" : "var(--t2)", font: "inherit", fontSize: 14, cursor: "pointer" }}>{i}</button>;
                })}
              </div>
              {nav()}
            </div>
          )}

          {step === 4 && (
            <div className="ob-step" key="4" style={{ textAlign: "left" }}>
              <h2 className="ob-title" style={{ textAlign: "center" }}>Connect your AI</h2>
              <p className="ob-body" style={{ textAlign: "center" }}>Use your own Claude API key, or run a free model on your computer with Ollama. You can change this later in Settings.</p>
              <ProviderPicker />
              <KeyFields />
              {nav(true)}
            </div>
          )}

          {step === 5 && (
            <div className="ob-step" key="5">
              <h2 className="ob-title">Bring in your schedule</h2>
              <p className="ob-body">Add your classes on the Schedule page, or just tell {s.assistantName.trim() || "me"} — “add networking class Tuesday at 9”.</p>
              <div className="stack" style={{ gap: 8, maxWidth: 320, width: "100%", margin: "0 auto" }}>
                <button type="button" className="btn btn-ghost" style={{ minHeight: 42 }} onClick={() => useApp.getState().flash("Calendar sync is coming in a future update")}><Icon d={ICONS.calendar} size={16} />Connect Google Calendar</button>
                <button type="button" className="btn-primary" onClick={finish}>Finish setup</button>
                <button type="button" className="btn btn-link" onClick={back}>Back</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
