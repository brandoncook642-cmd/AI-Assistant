// Shared data types for the assistant app.

export type Mode = "standard" | "focus" | "alert";
export type OrbState = "idle" | "listening" | "thinking" | "speaking";
export type Page = "home" | "chat" | "tasks" | "schedule" | "code" | "settings";
export type ThemeChoice = "dark" | "light" | "system";
export type Palette = "duo" | "mono" | "spectrum";
export type Provider = "claude" | "ollama" | "custom";
export type Due = "Today" | "Tomorrow" | "This week";
export type EventKind = "class" | "study" | "project" | "check";

export interface Task {
  id: string;
  label: string;
  due: Due;
  priority: boolean;
  done: boolean;
  createdAt: number;
}

export interface CalendarEvent {
  id: string;
  day: number; // 0 = Monday … 6 = Sunday
  start: number; // minutes after midnight
  duration: number; // minutes
  title: string;
  kind: EventKind;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  at: number;
}

export interface Notification {
  id: string;
  kind: "event" | "task" | "info";
  title: string;
  body: string;
  page?: Page;
  at: number;
  read: boolean;
  key?: string;
}

export interface Effects {
  bloom: boolean;
  trails: boolean;
  bgCore: boolean;
  cursor: boolean;
  tilt: boolean;
  mesh: boolean;
}

export interface Settings {
  userName: string;
  assistantName: string;
  theme: ThemeChoice;
  accent: string; // accent id from ACCENTS, or "custom"
  customAccent: string;
  palette: Palette;
  shape: string;
  density: number;
  particleSize: number;
  spin: number;
  coreFollowsMode: boolean;
  effects: Effects;
  // AI
  provider: Provider;
  apiKeys: { claude: string; custom: string };
  models: { claude: string; ollama: string; custom: string };
  urls: { ollama: string; custom: string };
  // Voice
  voiceURI: string;
  voiceRate: number;
  voicePitch: number;
  speechLang: string;
  spokenReplies: boolean;
  // Sound
  sound: boolean;
  volume: number;
  // Notifications
  remindEvents: boolean;
  nudgeTasks: boolean;
  leadMinutes: number;
  interests: string[];
}
