// Builds the system prompt from the user's real data, so the assistant
// knows their tasks, schedule and preferences.
import type { CalendarEvent, Mode, Settings, Task } from "../types";
import { DAY_LONG, fmtTime, todayIndex } from "../time";

export function assistantName(s: Settings): string {
  return s.assistantName.trim() || "Assistant";
}

export function buildSystemPrompt(s: Settings, tasks: Task[], events: CalendarEvent[], mode: Mode): string {
  const now = new Date();
  const ti = todayIndex(now);
  const open = tasks.filter((t) => !t.done);
  const today = events.filter((e) => e.day === ti).sort((a, b) => a.start - b.start);
  const week = events.slice().sort((a, b) => a.day - b.day || a.start - b.start);

  const lines = [
    `You are ${assistantName(s)}, a personal assistant inside a desktop and mobile app.`,
    s.userName ? `The user's name is ${s.userName}.` : "",
    s.interests.length ? `They mainly use you for: ${s.interests.join(", ")}.` : "",
    "",
    "Style: warm, direct and concise. Keep replies short — usually 1–3 sentences — unless the user asks for detail or for code.",
    "When explaining code, explain step by step for a learner and point out likely bugs.",
    "Use the tools to add tasks, complete tasks, add events and start focus sessions whenever the user asks you to (or clearly implies it). Confirm briefly afterwards.",
    "",
    `Current time: ${now.toLocaleString(undefined, { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" })}.`,
    `Current mode: ${mode}.`,
    "",
    open.length
      ? `Open tasks:\n${open.map((t) => `- ${t.label} (due ${t.due}${t.priority ? ", priority" : ""})`).join("\n")}`
      : "The user has no open tasks.",
    today.length
      ? `Today's schedule:\n${today.map((e) => `- ${fmtTime(e.start)}–${fmtTime(e.start + e.duration)} ${e.title}`).join("\n")}`
      : "Nothing is scheduled today.",
    week.length > today.length
      ? `This week:\n${week.filter((e) => e.day !== ti).map((e) => `- ${DAY_LONG[e.day]} ${fmtTime(e.start)} ${e.title}`).join("\n")}`
      : "",
  ];
  return lines.filter((l, i, a) => l !== "" || a[i - 1] !== "").join("\n");
}
