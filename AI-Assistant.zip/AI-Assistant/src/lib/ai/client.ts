// Talks to the AI provider the user picked in Settings.
//
// Keys never leave the user's device except to go straight to their provider:
// - Claude: called directly from the browser with the user's own key.
// - Ollama / custom: any OpenAI-compatible endpoint (Ollama runs locally).
import type { Settings } from "../types";
import { TOOLS, runTool } from "./tools";

export interface Turn {
  role: "user" | "assistant";
  text: string;
}

export class AiError extends Error {}

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const MAX_STEPS = 5;

export function isConfigured(s: Settings): boolean {
  if (s.provider === "claude") return s.apiKeys.claude.trim().length > 20;
  if (s.provider === "ollama") return /^https?:\/\//.test(s.urls.ollama) && !!s.models.ollama.trim();
  return /^https?:\/\/.+/.test(s.urls.custom) && !!s.models.custom.trim();
}

function openAiUrl(base: string): string {
  const b = base.replace(/\/+$/, "");
  return /\/v1$/.test(b) ? `${b}/chat/completions` : `${b}/v1/chat/completions`;
}

async function readError(res: Response): Promise<string> {
  try {
    const j = await res.json();
    return j?.error?.message || j?.error || res.statusText;
  } catch {
    return res.statusText;
  }
}

function friendly(provider: Settings["provider"], status: number, detail: string): string {
  if (status === 401 || status === 403) return "Your API key was rejected. Check it in Settings → AI connection.";
  if (status === 404 && provider === "ollama") return "That model isn't installed in Ollama. Run `ollama pull <model>` first.";
  if (status === 429) return "You've hit your provider's rate or spending limit. Try again shortly.";
  if (status === 529 || status === 503) return "The AI service is busy right now. Try again in a moment.";
  return `The AI request failed (${status}). ${detail}`;
}

async function callClaude(s: Settings, system: string, history: Turn[], onTool: (name: string) => void): Promise<string> {
  type Block = { type: string; text?: string; id?: string; name?: string; input?: Record<string, unknown> };
  const messages: { role: string; content: unknown }[] = history.map((t) => ({ role: t.role, content: t.text }));
  for (let step = 0; step < MAX_STEPS; step++) {
    let res: Response;
    try {
      res = await fetch(ANTHROPIC_URL, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": s.apiKeys.claude.trim(),
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: s.models.claude,
          max_tokens: 1024,
          system,
          messages,
          tools: TOOLS.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters })),
        }),
      });
    } catch {
      throw new AiError("Couldn't reach Claude. Check your internet connection.");
    }
    if (!res.ok) throw new AiError(friendly("claude", res.status, await readError(res)));
    const data = (await res.json()) as { content: Block[]; stop_reason: string };
    const text = data.content.filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
    const uses = data.content.filter((b) => b.type === "tool_use");
    if (data.stop_reason !== "tool_use" || uses.length === 0) return text;
    messages.push({ role: "assistant", content: data.content });
    messages.push({
      role: "user",
      content: uses.map((u) => {
        onTool(u.name!);
        return { type: "tool_result", tool_use_id: u.id, content: runTool(u.name!, u.input ?? {}) };
      }),
    });
  }
  return "Done.";
}

async function callOpenAiCompatible(s: Settings, system: string, history: Turn[], onTool: (name: string) => void): Promise<string> {
  const isOllama = s.provider === "ollama";
  const url = openAiUrl(isOllama ? s.urls.ollama : s.urls.custom);
  const model = isOllama ? s.models.ollama : s.models.custom;
  type Msg = { role: string; content: string | null; tool_calls?: unknown; tool_call_id?: string };
  const messages: Msg[] = [{ role: "system", content: system }, ...history.map((t) => ({ role: t.role, content: t.text }))];
  for (let step = 0; step < MAX_STEPS; step++) {
    let res: Response;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...(isOllama ? {} : { authorization: `Bearer ${s.apiKeys.custom.trim()}` }),
        },
        body: JSON.stringify({
          model,
          messages,
          tools: TOOLS.map((t) => ({ type: "function", function: t })),
        }),
      });
    } catch {
      throw new AiError(
        isOllama
          ? "Couldn't reach Ollama. Make sure it's running, and that OLLAMA_ORIGINS allows this site (see the README)."
          : "Couldn't reach your AI provider. Check the base URL.",
      );
    }
    if (!res.ok) throw new AiError(friendly(s.provider, res.status, await readError(res)));
    const data = await res.json();
    const msg = data?.choices?.[0]?.message ?? {};
    const calls: { id: string; function: { name: string; arguments: string } }[] = msg.tool_calls ?? [];
    if (!calls.length) return String(msg.content ?? "").trim();
    messages.push({ role: "assistant", content: msg.content ?? null, tool_calls: calls });
    for (const c of calls) {
      let args: Record<string, unknown> = {};
      try { args = JSON.parse(c.function.arguments || "{}"); } catch { /* model sent invalid JSON */ }
      onTool(c.function.name);
      messages.push({ role: "tool", tool_call_id: c.id, content: runTool(c.function.name, args) });
    }
  }
  return "Done.";
}

/** Sends the conversation to the selected provider, running any tools it asks for. */
export async function chat(settings: Settings, system: string, history: Turn[], onTool: (name: string) => void = () => {}): Promise<string> {
  if (!isConfigured(settings)) throw new AiError("No AI is connected yet. Add one in Settings → AI connection.");
  const trimmed = history.slice(-24);
  return settings.provider === "claude"
    ? callClaude(settings, system, trimmed, onTool)
    : callOpenAiCompatible(settings, system, trimmed, onTool);
}

/** Cheap request to confirm the key / server works. */
export async function testConnection(settings: Settings): Promise<string> {
  const reply = await chat(settings, "Reply with exactly: Connected.", [{ role: "user", text: "Test" }]);
  return reply || "Connected.";
}
