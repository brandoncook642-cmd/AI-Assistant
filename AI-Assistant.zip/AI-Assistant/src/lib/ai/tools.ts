// The actions the assistant is allowed to take in the app.
// Each tool has a JSON schema (so the model knows how to call it) and a
// handler that runs against the app state.
import { useApp } from "../store";
import type { Due, EventKind } from "../types";
import { DAY_LONG, fmtTime, todayIndex } from "../time";

export interface ToolDef {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export const TOOLS: ToolDef[] = [
  {
    name: "add_task",
    description: "Add a task to the user's task list.",
    parameters: {
      type: "object",
      properties: {
        label: { type: "string", description: "Short task description" },
        due: { type: "string", enum: ["Today", "Tomorrow", "This week"] },
        priority: { type: "boolean", description: "True if the task is important or urgent" },
      },
      required: ["label"],
    },
  },
  {
    name: "complete_task",
    description: "Mark one of the user's existing tasks as done. Match by label.",
    parameters: {
      type: "object",
      properties: { label: { type: "string", description: "The task's label, or a close match" } },
      required: ["label"],
    },
  },
  {
    name: "add_event",
    description: "Add an event to the user's weekly schedule.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        day: { type: "string", description: "today, tomorrow, or a weekday name like Wednesday" },
        start: { type: "string", description: "Start time in 24-hour HH:MM" },
        duration_minutes: { type: "number" },
        kind: { type: "string", enum: ["class", "study", "project", "check"] },
      },
      required: ["title", "day", "start"],
    },
  },
  {
    name: "start_focus_session",
    description: "Start a timed focus session and switch to Focus mode.",
    parameters: { type: "object", properties: {} },
  },
];

function parseDay(day: string): number {
  const d = day.trim().toLowerCase();
  const t = todayIndex();
  if (d === "today") return t;
  if (d === "tomorrow") return (t + 1) % 7;
  const i = DAY_LONG.findIndex((x) => x.toLowerCase().startsWith(d.slice(0, 3)));
  return i < 0 ? t : i;
}

function parseTime(s: string): number {
  const m = /^(\d{1,2}):?(\d{2})?\s*(am|pm)?$/i.exec(s.trim());
  if (!m) return 9 * 60;
  let h = Number(m[1]);
  const min = Number(m[2] ?? 0);
  if (m[3]?.toLowerCase() === "pm" && h < 12) h += 12;
  if (m[3]?.toLowerCase() === "am" && h === 12) h = 0;
  return Math.max(0, Math.min(23, h)) * 60 + Math.max(0, Math.min(59, min));
}

/** Runs a tool and returns a short text result for the model. */
export function runTool(name: string, input: Record<string, unknown>): string {
  const app = useApp.getState();
  switch (name) {
    case "add_task": {
      const due = (["Today", "Tomorrow", "This week"].includes(String(input.due)) ? input.due : "Today") as Due;
      const t = app.addTask(String(input.label ?? ""), due, Boolean(input.priority));
      return t ? `Added task "${t.label}" (due ${t.due}).` : "Could not add an empty task.";
    }
    case "complete_task": {
      const q = String(input.label ?? "").toLowerCase();
      const t = app.tasks.find((x) => !x.done && x.label.toLowerCase().includes(q)) ??
        app.tasks.find((x) => !x.done && q.includes(x.label.toLowerCase()));
      if (!t) return `No open task matches "${input.label}".`;
      app.toggleTask(t.id);
      return `Marked "${t.label}" as done.`;
    }
    case "add_event": {
      const kind = (["class", "study", "project", "check"].includes(String(input.kind)) ? input.kind : "study") as EventKind;
      const e = app.addEvent({
        title: String(input.title ?? ""),
        day: parseDay(String(input.day ?? "today")),
        start: parseTime(String(input.start ?? "09:00")),
        duration: Number(input.duration_minutes) || 60,
        kind,
      });
      return e ? `Added "${e.title}" on ${DAY_LONG[e.day]} at ${fmtTime(e.start)}.` : "Could not add that event.";
    }
    case "start_focus_session": {
      app.startFocus();
      return "Focus session started.";
    }
    default:
      return `Unknown tool ${name}.`;
  }
}
