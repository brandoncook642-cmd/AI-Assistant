// Interface sounds, generated live with the Web Audio API (no audio files).
import { useApp } from "./store";

export type SoundName = "listenOn" | "listenOff" | "send" | "reply" | "done" | "tick" | "bell" | "whoosh" | "boot" | "focus";

let ctx: AudioContext | null = null;
let last = 0;

export function playSound(name: SoundName) {
  const { sound, volume } = useApp.getState().settings;
  if (!sound || typeof window === "undefined") return;
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx ??= new AC();
    if (ctx.state === "suspended") void ctx.resume();
    const ac = ctx;
    const now = ac.currentTime;
    if (name === "tick" && now - last < 0.25) return;
    last = now;

    const master = ac.createGain();
    master.gain.value = volume * 0.5;
    master.connect(ac.destination);

    const tone = (freq: number, t0: number, dur: number, type: OscillatorType = "sine", peak = 0.3, glideTo?: number) => {
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, now + t0);
      if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, now + t0 + dur);
      g.gain.setValueAtTime(0.0001, now + t0);
      g.gain.exponentialRampToValueAtTime(peak, now + t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, now + t0 + dur);
      o.connect(g).connect(master);
      o.start(now + t0);
      o.stop(now + t0 + dur + 0.05);
    };
    const noise = (t0: number, dur: number, f0: number, f1: number, peak: number) => {
      const len = Math.floor(ac.sampleRate * dur);
      const buf = ac.createBuffer(1, len, ac.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      const src = ac.createBufferSource();
      src.buffer = buf;
      const bp = ac.createBiquadFilter();
      bp.type = "bandpass";
      bp.Q.value = 1.2;
      bp.frequency.setValueAtTime(f0, now + t0);
      bp.frequency.exponentialRampToValueAtTime(f1, now + t0 + dur);
      const g = ac.createGain();
      g.gain.setValueAtTime(0.0001, now + t0);
      g.gain.exponentialRampToValueAtTime(peak, now + t0 + dur * 0.4);
      g.gain.exponentialRampToValueAtTime(0.0001, now + t0 + dur);
      src.connect(bp).connect(g).connect(master);
      src.start(now + t0);
      src.stop(now + t0 + dur);
    };

    const sounds: Record<SoundName, () => void> = {
      listenOn: () => { tone(660, 0, 0.12, "sine", 0.25); tone(990, 0.08, 0.18, "sine", 0.22); },
      listenOff: () => { tone(880, 0, 0.12, "sine", 0.2); tone(587, 0.08, 0.2, "sine", 0.2); },
      send: () => tone(1200, 0, 0.09, "triangle", 0.18, 1800),
      reply: () => { tone(784, 0, 0.35, "sine", 0.14); tone(1175, 0.05, 0.4, "sine", 0.08); },
      done: () => { tone(784, 0, 0.14, "triangle", 0.2); tone(988, 0.07, 0.14, "triangle", 0.2); tone(1319, 0.14, 0.3, "triangle", 0.22); },
      tick: () => tone(1500, 0, 0.05, "sine", 0.08),
      bell: () => { tone(1047, 0, 0.6, "sine", 0.18); tone(1568, 0, 0.5, "sine", 0.07); tone(1319, 0.16, 0.7, "sine", 0.15); },
      whoosh: () => { noise(0, 0.6, 300, 3000, 0.25); tone(220, 0, 0.5, "sine", 0.1, 440); },
      boot: () => { noise(0, 1.4, 200, 2400, 0.12); tone(196, 0.1, 1.2, "sine", 0.1, 392); tone(784, 1.25, 0.6, "sine", 0.16); tone(1175, 1.35, 0.7, "sine", 0.1); },
      focus: () => { tone(523, 0, 0.5, "sine", 0.16); tone(659, 0.1, 0.5, "sine", 0.14); tone(784, 0.2, 0.7, "sine", 0.14); },
    };
    sounds[name]();
  } catch {
    /* audio not available */
  }
}
