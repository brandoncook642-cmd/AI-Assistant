// Writes the daily brief from the user's real data.
import type { CalendarEvent, Task } from "./types";
import { fmtTime, minutesNow, todayIndex } from "./time";

export function writeBrief(name: string, tasks: Task[], events: CalendarEvent[], hours: number[]): { title: string; text: string; chips: string[] } {
  const now = new Date();
  const h = now.getHours();
  const title = `Daily brief · ${h < 12 ? "Morning" : h < 18 ? "Afternoon" : "Evening"}`;
  const ti = todayIndex(now);
  const mins = minutesNow(now);
  const today = events.filter((e) => e.day === ti).sort((a, b) => a.start - b.start);
  const upcoming = today.filter((e) => e.start + e.duration > mins);
  const open = tasks.filter((t) => !t.done);
  const due = open.filter((t) => t.due === "Today");
  const top = [...open].sort((a, b) => Number(b.priority) - Number(a.priority))[0];
  const yesterday = ti > 0 ? hours[ti - 1] : 0;

  if (!events.length && !tasks.length && !hours.some((x) => x > 0)) {
    return {
      title,
      text: `Welcome to your first day with ${name}. Nothing is scheduled yet — add your classes on the Schedule page and I’ll plan study time around them. A short focus session is a great way to start a streak.`,
      chips: [],
    };
  }

  // First free gap of 45+ minutes from now.
  let gap: number | null = null;
  let cursor = Math.max(mins, 8 * 60);
  for (const e of today) {
    if (e.start - cursor >= 45 && e.start > mins) { gap = cursor; break; }
    cursor = Math.max(cursor, e.start + e.duration);
  }
  if (gap === null && cursor <= 21 * 60) gap = cursor;

  const parts: string[] = [];
  if (upcoming.length) parts.push(`You have ${upcoming.length} event${upcoming.length > 1 ? "s" : ""}${upcoming.length < today.length ? " left" : ""} today, starting with ${upcoming[0].title} at ${fmtTime(upcoming[0].start)}.`);
  else parts.push(today.length ? "Your scheduled events are done for today." : "Your calendar is clear today.");
  if (due.length) parts.push(`${due.length} task${due.length > 1 ? "s are" : " is"} due today${top ? `, and “${top.label}” is your top priority.` : "."}`);
  else if (top) parts.push(`Nothing is due today — “${top.label}” is a good one to get ahead on.`);
  if (yesterday > 0) parts.push(`You focused ${yesterday.toFixed(1)}h yesterday.`);
  if (gap !== null && top) parts.push(`You’re free from ${fmtTime(Math.ceil(gap / 15) * 15)} — a good time for ${top.label}.`);

  return { title, text: parts.join(" "), chips: [`${upcoming.length} upcoming`, `${due.length} due today`, `${yesterday.toFixed(1)}h yesterday`] };
}
