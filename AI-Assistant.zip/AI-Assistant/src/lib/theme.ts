// Colours, core shapes and mode colours.
import type { Mode } from "./types";

export const ACCENTS: { id: string; label: string; a: string; a2: string }[] = [
  { id: "ocean", label: "Ocean", a: "#4FB8FF", a2: "#6FF0D0" },
  { id: "mint", label: "Mint", a: "#4BE3A2", a2: "#7A6CFF" },
  { id: "violet", label: "Violet", a: "#9B7BFF", a2: "#FF7AD9" },
  { id: "rose", label: "Rose", a: "#FF6B9A", a2: "#FFB36B" },
  { id: "amber", label: "Amber", a: "#FFB020", a2: "#FF6B4A" },
  { id: "ice", label: "Ice", a: "#B8E6FF", a2: "#8C9BFF" },
  { id: "lime", label: "Lime", a: "#B6F04A", a2: "#3FD3C6" },
  { id: "crimson", label: "Crimson", a: "#FF4D5E", a2: "#9B7BFF" },
];

export const MODE_LABEL: Record<Mode, string> = { standard: "Standard", focus: "Focus", alert: "Alert" };

export const MODE_CORE: Record<Exclude<Mode, "standard">, [string, string]> = {
  focus: ["#9B7BFF", "#E07CFF"],
  alert: ["#FFB020", "#FF5A4A"],
};

// Index order matters: it matches the shape ids in the vertex shader.
export const SHAPES: { name: string; group: "signature" | "classic"; icon: string }[] = [
  { name: "Sphere", group: "classic", icon: "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" },
  { name: "Torus", group: "classic", icon: "M2 12c0-3 4.5-5 10-5s10 2 10 5-4.5 5-10 5S2 15 2 12zM8 12c0-1 1.8-1.6 4-1.6s4 .6 4 1.6" },
  { name: "Galaxy", group: "classic", icon: "M10.5 12a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0M12 4c5 0 8 3 8 7M12 20c-5 0-8-3-8-7M20 11c0 4-4 6-7 5M4 13c0-4 4-6 7-5" },
  { name: "Atom", group: "classic", icon: "M2 12a10 4 0 1 0 20 0a10 4 0 1 0-20 0M8 12a4 10 0 1 0 8 0a4 10 0 1 0-8 0M11 12a1 1 0 1 0 2 0a1 1 0 1 0-2 0" },
  { name: "Planet", group: "classic", icon: "M7 12a5 5 0 1 0 10 0a5 5 0 1 0-10 0M2 13c0-2 4.5-3 10-3s10 1 10 3-4.5 2.5-10 2.5S2 15 2 13z" },
  { name: "Gyro", group: "signature", icon: "M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M3 12a9 3 0 1 0 18 0a9 3 0 1 0-18 0M9 12a3 9 0 1 0 6 0a3 9 0 1 0-6 0" },
  { name: "Ripple", group: "classic", icon: "M11 12a1 1 0 1 0 2 0a1 1 0 1 0-2 0M7 12a5 5 0 1 0 10 0a5 5 0 1 0-10 0M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0" },
  { name: "Vortex", group: "classic", icon: "M3 5c0-1 4-2 9-2s9 1 9 2-4 2-9 2-9-1-9-2zM6 11c0-1 2.7-1.6 6-1.6s6 .6 6 1.6-2.7 1.6-6 1.6S6 12 6 11zM9 17c0-.6 1.3-1 3-1s3 .4 3 1-1.3 1-3 1-3-.4-3-1zM12 18v3" },
  { name: "Shell", group: "signature", icon: "M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M8 12a4 4 0 1 0 8 0a4 4 0 1 0-8 0" },
  { name: "Armillary", group: "signature", icon: "M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M4 8l16 8M4 16l16-8M3 12a9 3 0 1 0 18 0a9 3 0 1 0-18 0M10.5 12a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0" },
  { name: "Gimbal", group: "signature", icon: "M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0M5 12a7 3 0 1 0 14 0a7 3 0 1 0-14 0M10 12a2 5 0 1 0 4 0a2 5 0 1 0-4 0" },
  { name: "Cage", group: "signature", icon: "M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M3 12h18M5 7h14M5 17h14M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18M10.5 12a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0" },
  { name: "Nested", group: "signature", icon: "M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0M6 12a6 6 0 1 0 12 0a6 6 0 1 0-12 0M10 12a2 2 0 1 0 4 0a2 2 0 1 0-4 0" },
  { name: "Dyson", group: "signature", icon: "M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0M5 6h14M3 10h18M3 14h18M5 18h14" },
  { name: "Corona", group: "signature", icon: "M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3" },
];

export function shapeIndex(name: string): number {
  const i = SHAPES.findIndex((s) => s.name === name);
  return i < 0 ? 9 : i;
}

export function hexToRgb(hex: string): [number, number, number] {
  const x = hex.replace("#", "");
  return [parseInt(x.slice(0, 2), 16), parseInt(x.slice(2, 4), 16), parseInt(x.slice(4, 6), 16)];
}

export function rgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${alpha})`;
}

/** Rotate a colour's hue, used to build a second colour for custom accents. */
export function shiftHue(hex: string, deg: number): string {
  const [r, g, b] = hexToRgb(hex).map((v) => v / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h /= 6;
  }
  h = (h + deg / 360) % 1;
  const f = (n: number) => {
    const k = (n + h * 12) % 12;
    const a = s * Math.min(l, 1 - l);
    return Math.round((l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1))) * 255);
  };
  return "#" + [f(0), f(8), f(4)].map((v) => v.toString(16).padStart(2, "0")).join("");
}

export interface ResolvedColours {
  accent: string;
  accent2: string;
  core: string;
  core2: string;
}

export function resolveColours(accentId: string, custom: string, mode: Mode, followMode: boolean): ResolvedColours {
  let a: string, a2: string;
  if (accentId === "custom") {
    a = custom;
    a2 = shiftHue(custom, 70);
  } else {
    const found = ACCENTS.find((x) => x.id === accentId) ?? ACCENTS[0];
    a = found.a;
    a2 = found.a2;
  }
  // Alert always recolours the interface so warnings stand out.
  const accent = mode === "alert" ? MODE_CORE.alert[0] : a;
  const accent2 = mode === "alert" ? MODE_CORE.alert[1] : a2;
  const [core, core2] = followMode && mode !== "standard" ? MODE_CORE[mode] : [accent, accent2];
  return { accent, accent2, core, core2 };
}
