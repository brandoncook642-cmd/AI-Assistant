"use client";
// App state. Everything except the short-lived UI state is saved to this device
// (localStorage) so nothing resets on reload. Accounts and cloud sync come later.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  CalendarEvent, ChatMessage, Due, EventKind, Mode, Notification, OrbState, Page, Settings, Task,
} from "./types";
import { dateKey, todayIndex, uid } from "./time";

export const DEFAULT_SETTINGS: Settings = {
  userName: "",
  assistantName: "",
  theme: "dark",
  accent: "ocean",
  customAccent: "#4FB8FF",
  palette: "duo",
  shape: "Armillary",
  density: 1,
  particleSize: 1,
  spin: 1,
  coreFollowsMode: true,
  effects: { bloom: true, trails: true, bgCore: true, cursor: true, tilt: true, mesh: true },
  provider: "claude",
  apiKeys: { claude: "", custom: "" },
  models: { claude: "claude-sonnet-5-5", ollama: "qwen2.5:7b", custom: "" },
  urls: { ollama: "http://localhost:11434", custom: "https://" },
  voiceURI: "",
  voiceRate: 1,
  voicePitch: 1,
  speechLang: "en-NZ",
  spokenReplies: false,
  sound: true,
  volume: 0.6,
  remindEvents: true,
  nudgeTasks: true,
  leadMinutes: 10,
  interests: [],
};

export interface FocusSession {
  date: string; // YYYY-MM-DD
  minutes: number;
}

interface PersistedState {
  onboarded: boolean;
  settings: Settings;
  tasks: Task[];
  events: CalendarEvent[];
  messages: ChatMessage[];
  sessions: FocusSession[];
  notifications: Notification[];
  notifiedKeys: string[];
  briefHiddenOn: string;
  startHidden: boolean;
  customised: boolean;
}

interface UiState {
  page: Page;
  mode: Mode;
  orb: OrbState;
  focusStart: number | null;
  paletteOpen: boolean;
  toast: { id: number; text: string } | null;
  hydrated: boolean;
}

interface Actions {
  set: (p: Partial<PersistedState & UiState>) => void;
  updateSettings: (p: Partial<Settings>) => void;
  completeOnboarding: () => void;
  addTask: (label: string, due?: Due, priority?: boolean) => Task | null;
  toggleTask: (id: string) => boolean; // returns new done state
  removeTask: (id: string) => void;
  clearDone: () => void;
  addEvent: (e: { title: string; day: number; start: number; duration: number; kind: EventKind }) => CalendarEvent | null;
  removeEvent: (id: string) => void;
  addMessage: (role: ChatMessage["role"], text: string) => ChatMessage;
  updateMessage: (id: string, text: string) => void;
  clearChat: () => void;
  notify: (n: Omit<Notification, "id" | "at" | "read">) => boolean;
  markAllRead: () => void;
  readNotification: (id: string) => void;
  clearNotifications: () => void;
  startFocus: () => void;
  stopFocus: () => number;
  flash: (text: string) => void;
  resetAll: () => void;
}

export type AppState = PersistedState & UiState & Actions;

const initialPersisted: PersistedState = {
  onboarded: false,
  settings: DEFAULT_SETTINGS,
  tasks: [],
  events: [],
  messages: [],
  sessions: [],
  notifications: [],
  notifiedKeys: [],
  briefHiddenOn: "",
  startHidden: false,
  customised: false,
};

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      ...initialPersisted,
      page: "home",
      mode: "standard",
      orb: "idle",
      focusStart: null,
      paletteOpen: false,
      toast: null,
      hydrated: false,

      set: (p) => set(p),
      updateSettings: (p) => set({ settings: { ...get().settings, ...p } }),
      completeOnboarding: () => set({ onboarded: true }),

      addTask: (label, due = "Today", priority = false) => {
        const clean = label.trim();
        if (!clean) return null;
        const t: Task = { id: uid(), label: clean, due, priority, done: false, createdAt: Date.now() };
        set({ tasks: [t, ...get().tasks] });
        return t;
      },
      toggleTask: (id) => {
        let now = false;
        set({ tasks: get().tasks.map((t) => (t.id === id ? ((now = !t.done), { ...t, done: !t.done }) : t)) });
        return now;
      },
      removeTask: (id) => set({ tasks: get().tasks.filter((t) => t.id !== id) }),
      clearDone: () => set({ tasks: get().tasks.filter((t) => !t.done) }),

      addEvent: ({ title, day, start, duration, kind }) => {
        const clean = title.trim();
        if (!clean) return null;
        const s = Math.max(0, Math.min(1439, start));
        const e: CalendarEvent = { id: uid(), title: clean, day: Math.max(0, Math.min(6, day)), start: s, duration: Math.max(15, Math.min(duration, 1440 - s)), kind };
        set({ events: [...get().events, e] });
        return e;
      },
      removeEvent: (id) => set({ events: get().events.filter((e) => e.id !== id) }),

      addMessage: (role, text) => {
        const m: ChatMessage = { id: uid(), role, text, at: Date.now() };
        set({ messages: [...get().messages, m].slice(-200) });
        return m;
      },
      updateMessage: (id, text) => set({ messages: get().messages.map((m) => (m.id === id ? { ...m, text } : m)) }),
      clearChat: () => set({ messages: [] }),

      notify: (n) => {
        if (n.key && get().notifiedKeys.includes(n.key)) return false;
        const item: Notification = { ...n, id: uid(), at: Date.now(), read: false };
        set({
          notifications: [item, ...get().notifications].slice(0, 40),
          notifiedKeys: n.key ? [...get().notifiedKeys, n.key].slice(-200) : get().notifiedKeys,
        });
        return true;
      },
      markAllRead: () => set({ notifications: get().notifications.map((n) => ({ ...n, read: true })) }),
      readNotification: (id) => set({ notifications: get().notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) }),
      clearNotifications: () => set({ notifications: [] }),

      startFocus: () => {
        if (get().focusStart) return;
        set({ focusStart: Date.now(), mode: "focus" });
      },
      stopFocus: () => {
        const start = get().focusStart;
        if (!start) return 0;
        const minutes = Math.max(1, Math.round((Date.now() - start) / 60000));
        set({ focusStart: null, mode: "standard", sessions: [...get().sessions, { date: dateKey(), minutes }].slice(-400) });
        return minutes;
      },

      flash: (text) => set({ toast: { id: Date.now(), text } }),
      resetAll: () => set({ ...initialPersisted, page: "home", mode: "standard", orb: "idle", focusStart: null }),
    }),
    {
      name: "assistant-app",
      storage: createJSONStorage(() => localStorage),
      version: 1,
      partialize: (s) => ({
        onboarded: s.onboarded,
        settings: s.settings,
        tasks: s.tasks,
        events: s.events,
        messages: s.messages,
        sessions: s.sessions,
        notifications: s.notifications,
        notifiedKeys: s.notifiedKeys,
        briefHiddenOn: s.briefHiddenOn,
        startHidden: s.startHidden,
        customised: s.customised,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<PersistedState>;
        return { ...current, ...p, settings: { ...DEFAULT_SETTINGS, ...(p.settings ?? {}), effects: { ...DEFAULT_SETTINGS.effects, ...(p.settings?.effects ?? {}) } } };
      },
      // Runs during store creation, so defer until `useApp` exists.
      onRehydrateStorage: () => () => { setTimeout(() => useApp.setState({ hydrated: true }), 0); },
    },
  ),
);

/** Focus hours for each day of the current week (Mon–Sun). */
export function weekHours(sessions: FocusSession[]): number[] {
  const out = [0, 0, 0, 0, 0, 0, 0];
  const now = new Date();
  const ti = todayIndex(now);
  for (let i = 0; i <= 6; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() - ti + i);
    const k = dateKey(d);
    out[i] = sessions.filter((s) => s.date === k).reduce((a, s) => a + s.minutes, 0) / 60;
  }
  return out;
}

/** Consecutive days (ending today or yesterday) with at least one focus session. */
export function streakDays(sessions: FocusSession[]): number {
  const days = new Set(sessions.map((s) => s.date));
  const d = new Date();
  if (!days.has(dateKey(d))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (days.has(dateKey(d))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}
