// Voice input (speech recognition) and output (speech synthesis) using the
// browser's built-in APIs. Free, and works best in Chrome and Edge.
import { useApp } from "./store";

type Recognition = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
};

export function speechInputSupported(): boolean {
  if (typeof window === "undefined") return false;
  const w = window as unknown as Record<string, unknown>;
  return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export function createRecognizer(onText: (text: string) => void, onEnd: (finalText: string) => void, onError: (msg: string) => void) {
  const w = window as unknown as Record<string, new () => Recognition>;
  const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!SR) return null;
  const rec = new SR();
  rec.lang = useApp.getState().settings.speechLang || "en-NZ";
  rec.interimResults = true;
  rec.continuous = false;
  let heard = "";
  rec.onresult = (e) => {
    let txt = "";
    for (let i = 0; i < e.results.length; i++) txt += e.results[i][0].transcript;
    heard = txt;
    onText(txt);
  };
  rec.onend = () => onEnd(heard.trim());
  rec.onerror = (e) => {
    if (e.error === "not-allowed") onError("Microphone access was blocked.");
    else if (e.error !== "no-speech" && e.error !== "aborted") onError("Voice input stopped: " + e.error);
  };
  return rec;
}

export function listVoices(): SpeechSynthesisVoice[] {
  if (typeof window === "undefined" || !window.speechSynthesis) return [];
  return window.speechSynthesis.getVoices();
}

/** Speaks text with the user's chosen voice. Calls onWord on each word boundary. */
export function speak(text: string, onWord?: () => void, onEnd?: () => void): boolean {
  if (typeof window === "undefined" || !window.speechSynthesis) return false;
  const { voiceURI, voiceRate, voicePitch } = useApp.getState().settings;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  const v = listVoices().find((x) => x.voiceURI === voiceURI);
  if (v) u.voice = v;
  u.rate = voiceRate;
  u.pitch = voicePitch;
  u.onboundary = () => onWord?.();
  u.onend = () => onEnd?.();
  u.onerror = () => onEnd?.();
  window.speechSynthesis.speak(u);
  return true;
}

export function stopSpeaking() {
  if (typeof window !== "undefined") window.speechSynthesis?.cancel();
}
