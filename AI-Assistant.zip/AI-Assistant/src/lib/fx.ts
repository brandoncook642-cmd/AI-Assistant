"use client";
// One-off visual effects: task-complete bursts and mode-change ripples.
import { create } from "zustand";

interface Burst { id: number; x: number; y: number }
interface Ripple { id: number; x: number; y: number; colour: string }

export const useFx = create<{ bursts: Burst[]; ripples: Ripple[] }>(() => ({ bursts: [], ripples: [] }));

export function burstAt(x: number, y: number) {
  const id = Date.now() + Math.random();
  useFx.setState((s) => ({ bursts: [...s.bursts, { id, x, y }] }));
  setTimeout(() => useFx.setState((s) => ({ bursts: s.bursts.filter((b) => b.id !== id) })), 900);
}

export function rippleFrom(x: number, y: number, colour: string) {
  const id = Date.now() + Math.random();
  useFx.setState((s) => ({ ripples: [...s.ripples, { id, x, y, colour }] }));
  setTimeout(() => useFx.setState((s) => ({ ripples: s.ripples.filter((r) => r.id !== id) })), 1300);
}
