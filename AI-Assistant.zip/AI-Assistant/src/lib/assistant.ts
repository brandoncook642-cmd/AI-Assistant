"use client";
// The conversation loop: sending messages, getting replies, voice in and out,
// and keeping the particle core's state in step with what's happening.
import { useApp } from "./store";
import { chat, isConfigured, AiError } from "./ai/client";
import { buildSystemPrompt } from "./ai/prompt";
import { runTool } from "./ai/tools";
import { createRecognizer, speak, stopSpeaking } from "./speech";
import { playSound } from "./sound";
import { core } from "@/components/core/coreState";
import type { Mode } from "./types";
import { rippleFrom } from "./fx";
import { resolveColours } from "./theme";

let streamTimer: ReturnType<typeof setInterval> | null = null;
let busy = false;

function setOrb(orb: "idle" | "listening" | "thinking" | "speaking") {
  useApp.setState({ orb });
  core.orb = orb;
}

/** Shows a reply word by word while the core "speaks" it. */
function deliver(text: string) {
  const app = useApp.getState();
  const msg = app.addMessage("assistant", "");
  const words = text.split(/(\s+)/);
  let i = 0;
  let voiceDone = !app.settings.spokenReplies;
  let streamDone = false;
  setOrb("speaking");
  playSound("reply");
  core.talking = true;
  const finish = () => {
    if (voiceDone && streamDone) {
      core.talking = false;
      setTimeout(() => { if (useApp.getState().orb === "speaking") setOrb("idle"); }, 400);
    }
  };
  if (app.settings.spokenReplies) {
    const ok = speak(text, () => { core.kick = 1; }, () => { voiceDone = true; finish(); });
    if (!ok) voiceDone = true;
  }
  if (streamTimer) clearInterval(streamTimer);
  streamTimer = setInterval(() => {
    i += 2;
    core.kick = 0.7 + Math.random() * 0.3;
    useApp.getState().updateMessage(msg.id, words.slice(0, i).join(""));
    if (i >= words.length) {
      clearInterval(streamTimer!);
      streamTimer = null;
      streamDone = true;
      finish();
    }
  }, 45);
}

/** Simple replies used when no AI provider is connected yet. */
function offlineReply(text: string): string {
  const t = text.toLowerCase();
  const add = /^(?:please\s+)?(?:add|create|new)\s+(?:a\s+)?task:?\s+(.+)/i.exec(text);
  if (add) return runTool("add_task", { label: add[1] }).replace(/^Added task/, "Added").replace(/\(due Today\)\./, "to today's tasks.");
  if (t.includes("focus")) { runTool("start_focus_session", {}); return "Focus session started. I'll keep time for you."; }
  if (/^(hi|hey|hello|kia ora)\b/.test(t)) return "Hey! Connect an AI in Settings → AI connection and I can really help. Until then I can add tasks and start focus sessions.";
  return "I'm not connected to an AI yet. Add your Claude API key, or point me at Ollama, in Settings → AI connection.";
}

export async function send(text: string) {
  const clean = text.trim();
  if (!clean || busy) return;
  busy = true;
  stopSpeaking();
  const app = useApp.getState();
  const history = app.messages.slice(-20).map((m) => ({ role: m.role, text: m.text })).filter((m) => m.text);
  app.addMessage("user", clean);
  playSound("send");
  setOrb("thinking");
  try {
    let reply: string;
    if (isConfigured(app.settings)) {
      const s = useApp.getState();
      reply = await chat(s.settings, buildSystemPrompt(s.settings, s.tasks, s.events, s.mode), [...history, { role: "user", text: clean }]);
      if (!reply) reply = "Done.";
    } else {
      await new Promise((r) => setTimeout(r, 700));
      reply = offlineReply(clean);
    }
    deliver(reply);
  } catch (e) {
    deliver(e instanceof AiError ? e.message : "Something went wrong talking to the AI. Please try again.");
  } finally {
    busy = false;
  }
}

/* ---------------- voice input ---------------- */

let recognizer: ReturnType<typeof createRecognizer> = null;
let stream: MediaStream | null = null;
let audioCtx: AudioContext | null = null;
let levelRaf = 0;

function stopLevel() {
  cancelAnimationFrame(levelRaf);
  stream?.getTracks().forEach((t) => t.stop());
  void audioCtx?.close();
  stream = null;
  audioCtx = null;
  core.level = 0;
}

export function isListening() {
  return useApp.getState().orb === "listening";
}

export function startListening(onPartial: (text: string) => void) {
  stopSpeaking();
  setOrb("listening");
  playSound("listenOn");
  navigator.mediaDevices?.getUserMedia({ audio: true }).then((s) => {
    if (!isListening()) { s.getTracks().forEach((t) => t.stop()); return; }
    stream = s;
    audioCtx = new AudioContext();
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 512;
    audioCtx.createMediaStreamSource(s).connect(analyser);
    const data = new Uint8Array(analyser.fftSize);
    const loop = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) { const x = (data[i] - 128) / 128; sum += x * x; }
      core.level = Math.min(1, Math.sqrt(sum / data.length) * 4);
      levelRaf = requestAnimationFrame(loop);
    };
    loop();
  }).catch(() => { /* level meter is optional */ });

  recognizer = createRecognizer(
    onPartial,
    (finalText) => {
      if (!isListening()) return;
      stopLevel();
      playSound("listenOff");
      setOrb("idle");
      if (finalText) void send(finalText);
    },
    (msg) => { useApp.getState().flash(msg); stopListening(); },
  );
  if (!recognizer) {
    useApp.getState().flash("Voice input needs Chrome or Edge");
    stopListening();
    return;
  }
  recognizer.start();
}

export function stopListening() {
  try { recognizer?.stop(); } catch { /* already stopped */ }
  recognizer = null;
  stopLevel();
  if (isListening()) { playSound("listenOff"); setOrb("idle"); }
}

/* ---------------- modes ---------------- */

export function changeMode(mode: Mode, origin?: { x: number; y: number }) {
  const app = useApp.getState();
  if (app.mode === mode) return;
  const { core: coreColour } = resolveColours(app.settings.accent, app.settings.customAccent, mode, app.settings.coreFollowsMode);
  const x = origin?.x ?? window.innerWidth / 2;
  const y = origin?.y ?? window.innerHeight / 3;
  rippleFrom(x, y, coreColour);
  core.shockStart = performance.now();
  playSound("whoosh");
  useApp.setState({ mode });
}
