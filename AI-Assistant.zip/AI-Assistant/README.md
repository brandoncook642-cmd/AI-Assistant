# Assistant

A personal AI assistant for study, code and planning — with a live WebGL particle core that reacts to what the assistant is doing.

Built with **Next.js**, **React** and **TypeScript**. Users bring their own AI: a Claude API key, a free local model through **Ollama**, or any OpenAI-compatible service.

## Features

- **Particle core** — 15 shapes (Armillary, Gyro, Shell, Gimbal…) that morph into each other and react to four states: idle, listening, thinking and speaking.
- **Real AI with actions** — the assistant can add tasks, complete tasks, add events and start focus sessions for you (tool use).
- **Bring your own AI** — Claude (Haiku, Sonnet or Opus), Ollama, or a custom OpenAI-compatible endpoint. Keys are stored only in your browser.
- **Voice** — speech input, spoken replies, choice of voice, speed and pitch.
- **Tasks, schedule and focus sessions** — with reminders, a daily brief and a weekly focus chart.
- **Code explainer** — paste code and get a step-by-step explanation or a bug review.
- **Command palette** — press ⌘K / Ctrl+K.
- **Personalisation** — light/dark theme, 8 accent colours plus custom, particle palettes, effects toggles, sounds.
- **Fresh start** — first launch runs a short setup; nothing is pre-filled.

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Connecting an AI

Open **Settings → AI connection**.

### Claude
1. Create an API key at [console.anthropic.com](https://console.anthropic.com).
2. **Set a monthly spending limit** in the console.
3. Paste the key and press **Test connection**.

The key is saved in your browser's local storage and sent directly to Anthropic. It is never sent to this app's server.

### Ollama (free, local)
1. Install [Ollama](https://ollama.com) and pull a model that supports tools, e.g. `ollama pull qwen2.5:7b`.
2. Allow the app to talk to Ollama from the browser:
   - macOS: `launchctl setenv OLLAMA_ORIGINS "*"` then restart Ollama
   - Windows: set a user environment variable `OLLAMA_ORIGINS` to `*` then restart Ollama
   - Linux: `OLLAMA_ORIGINS="*" ollama serve`
3. In Settings choose **Ollama**, keep `http://localhost:11434`, and enter the model name.

Ollama only works while it's running on the same computer you're using.

## Project structure

```
src/
  app/                  Next.js entry (layout, page, global styles)
  components/
    AssistantApp.tsx    Root: theme, startup, page switching, overlays
    core/               WebGL particle core (shaders, engine, live state)
    shell/              Navigation rail, top bar, command palette
    assistant/          Message box and message list
    views/              Home, Chat, Tasks, Schedule, Code, Settings, Onboarding
    ui.tsx              Small shared components (Switch, Segmented, icons…)
  lib/
    store.ts            App state (Zustand), saved to localStorage
    ai/                 AI client, tools and system prompt
    assistant.ts        Conversation loop and voice input
    speech.ts           Speech recognition and synthesis
    sound.ts            Interface sounds (Web Audio)
    theme.ts            Accent colours, core shapes, mode colours
```

## Deploying

The easiest option is [Vercel](https://vercel.com): import the GitHub repository and deploy — no environment variables are needed, because each user supplies their own AI key in Settings.

## Roadmap

- Accounts and cloud sync (Supabase)
- Google Calendar sync
- Higher-quality voices
- Install as a phone app (PWA)
